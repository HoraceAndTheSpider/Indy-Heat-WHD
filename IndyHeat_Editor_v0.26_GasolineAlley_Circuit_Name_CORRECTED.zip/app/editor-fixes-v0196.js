(function(root){
'use strict';

/*
 * Indy Heat Circuit Editor v0.26.
 *
 * This module intentionally runs after editor-fixes-v0193.js (currently v0.19.5).
 *
 * It carries the established live-editor acceptance fixes plus the v0.26 Gasoline Alley circuit-name authoring, v0.25 overlay-colour controls, v0.24 Recovery interaction update and the existing lap slider:
 * 1. Lap-tower dragging no longer depends on any particular canvas/div receiving
 *    the pointer event. A document-level capture listener checks the pointer's
 *    coordinates against the visible HUD rectangle before any editor canvas sees it.
 * 2. "From backdrop" uses the explicit Race-index -> Garage-index palette lookup
 *    supplied in palette compare.xlsx, with no algorithmic colour matching.
 * 3. Circuit ZIPs may carry optional 18-byte name.bin data for Gasoline Alley.
 * 4. Final mode order is:
 *      Backdrop, Foreground, Surface,
 *      Waypoints, Recovery, Race,
 *      MiniMap, Map.
 */

if(typeof document==='undefined')return;

const $=id=>document.getElementById(id);
const TRACK_W=320,TRACK_H=256;
const PREVIEW_W=78,PREVIEW_H=51,TRACK_GAME_H=224;

const NAME_OFFSET=0x70;
const NAME_SIZE=0x12;
const NAME_DISPLAY_SIZE=0x11;
const NAME_LEFT_FILL=0x3c; // '<'
const NAME_RIGHT_FILL=0x40; // '@'


// Explicit lookup supplied by the project owner.
// Source = Race palette index. Destination = Garage / Gasoline Alley palette index.
// The spreadsheet row labelled Hex Index 028:$900 contains "Race # 29"; because
// the Hex Index is 028 and the following row is the genuine 029 entry, that row
// is treated as the evident source-index typo 28 -> 4.
const RACE_TO_GARAGE=Object.freeze([
  14, //  0 -> 14
   0, //  1 -> 0
  19, //  2 -> 19
   3, //  3 -> 3
  12, //  4 -> 12
  13, //  5 -> 13
  14, //  6 -> 14
  15, //  7 -> 15
  29, //  8 -> 29
  27, //  9 -> 27
  17, // 10 -> 17
  31, // 11 -> 31
  20, // 12 -> 20
  21, // 13 -> 21
  22, // 14 -> 22
  23, // 15 -> 23
  25, // 16 -> 25
  25, // 17 -> 25
  26, // 18 -> 26
  19, // 19 -> 19
  28, // 20 -> 28
  31, // 21 -> 31
  30, // 22 -> 30
  31, // 23 -> 31
  24, // 24 -> 24
   8, // 25 -> 8
   9, // 26 -> 9
  10, // 27 -> 10
   4, // 28 -> 4  (spreadsheet Hex Index 028)
   6, // 29 -> 6
   5, // 30 -> 5
   7  // 31 -> 7
]);

const MODE_ORDER=Object.freeze([
  'layerEditBackdrop',
  'layerEditMask',
  'layerEditSurface',
  'layerModeWaypoints',
  'layerEditRecovery',
  'layerEditRaceSetup',
  'layerEditMini',
  'layerEditMap'
]);

let hudDrag=null;
let paletteInstalled=false;
let bootTimer=null;
let zipHookBusy=false;
const authoredNames=new Map();

function tools(){return root.IndyHeatTools||null;}
function packageTools(){return root.IndyHeatCircuitPackage||null;}
function capture(){return root.IndyHeatRaceSetupCapture||null;}
function trackIndex(){return Number($('trackSelect')?.value||0);}

function uniq(items){
  const out=[];
  for(const x of items)if(x&&!out.includes(x))out.push(x);
  return out;
}
function models(){
  const C=capture();
  return C?uniq([C.coreModel,C.layerModel,C.model,...(C.models||[])]):[];
}
function primaryModel(){
  const C=capture();
  return C?.model||C?.layerModel||C?.coreModel||models()[0]||null;
}
function resourceModel(){
  const C=capture();
  return C?.layerModel||C?.model||C?.coreModel||models()[0]||null;
}
function recordsFor(model){
  const C=capture(),T=tools();
  if(!model||!T)return [];
  let records=C?.recordsByMain?.get(model.main)||null;
  if(!records){
    records=T.parseRaceRecords(model.main);
    C?.recordsByMain?.set(model.main,records);
  }
  for(const r of records){
    if(r.baseResourceId==null&&typeof T.raceBaseResourceId==='function')
      r.baseResourceId=T.raceBaseResourceId(r,model.resourceTableOffset+0x1000);
  }
  return records;
}
function recordFor(model,index=trackIndex()){
  const T=tools();
  if(!model||!T)return null;
  const base=T.TRACK_BASE_IDS?.[index];
  return recordsFor(model).find(r=>r.baseResourceId===base)||null;
}
function currentPresentation(){
  const P=packageTools(),m=primaryModel(),r=recordFor(m);
  return P&&m&&r?P.readPresentation(m.main,r.offset):null;
}

function decodeNameBytes(bytes){
  if(!(bytes instanceof Uint8Array))bytes=new Uint8Array(bytes||[]);
  let s='';
  for(let i=0;i<Math.min(NAME_DISPLAY_SIZE,bytes.length);i++){
    const c=bytes[i];
    if(c===0)break;
    if(c===NAME_LEFT_FILL||c===NAME_RIGHT_FILL)s+=' ';
    else if(c>=32&&c<=126)s+=String.fromCharCode(c);
  }
  return s.replace(/\s+/g,' ').trim();
}

function encodeNameBytes(value){
  const name=String(value??'').replace(/\s+/g,' ').trim();
  if(!name)throw new Error('Circuit name must not be blank');
  if(name.length>NAME_DISPLAY_SIZE)throw new Error(`Circuit name is limited to ${NAME_DISPLAY_SIZE} characters`);
  for(let i=0;i<name.length;i++){
    const c=name.charCodeAt(i);
    if(c<32||c>126||c===NAME_LEFT_FILL||c===NAME_RIGHT_FILL)
      throw new Error("Circuit name must use printable ASCII and cannot contain '<' or '@'");
  }
  const out=new Uint8Array(NAME_SIZE);
  const free=NAME_DISPLAY_SIZE-name.length;
  const left=Math.floor(free/2),right=free-left;
  let p=0;
  for(let i=0;i<left;i++)out[p++]=NAME_LEFT_FILL;
  for(let i=0;i<name.length;i++)out[p++]=name.charCodeAt(i);
  for(let i=0;i<right;i++)out[p++]=NAME_RIGHT_FILL;
  out[NAME_DISPLAY_SIZE]=0;
  return out;
}

function addNameFileToZipBytes(P,zipBytes,circuitIndex,nameBytes){
  if(!P||typeof P.readZipStore!=='function'||typeof P.zipStore!=='function'||typeof P.circuitFolder!=='function')
    throw new Error('Circuit package tools are unavailable');
  if(!(nameBytes instanceof Uint8Array))nameBytes=new Uint8Array(nameBytes||[]);
  if(nameBytes.length!==NAME_SIZE)throw new Error(`name.bin must be exactly $${NAME_SIZE.toString(16).toUpperCase()} bytes`);
  const entries=P.readZipStore(zipBytes);
  entries.set(`${P.circuitFolder(circuitIndex)}/name.bin`,nameBytes.slice());
  return P.zipStore([...entries.entries()].map(([name,data])=>({name,data})));
}

root.IndyHeatCircuitNameTools={NAME_OFFSET,NAME_SIZE,NAME_DISPLAY_SIZE,decodeNameBytes,encodeNameBytes,addNameFileToZipBytes};

function setVersion(){
  const h=document.querySelector('header h1');
  if(h)h.textContent='Indy Heat Amiga — Circuit Editor v0.26';
  document.title='Indy Heat Amiga – Circuit Editor v0.26';
}


/* -------------------------------------------------------------------------
 * Overlay display colours.
 *
 * layer-editor.js owns the Foreground/Surface drawing canvas and historically
 * used literal colours inside its private draw functions. Keep that owner
 * untouched in this focused pass, but remap only its known overlay fillRect
 * colours at the canvas boundary. This changes presentation only; resource
 * bytes, surface classes and mask bits are never modified.
 * ---------------------------------------------------------------------- */
const OVERLAY_COLOUR_STORAGE='indyheat-overlay-colours-v025';
const OVERLAY_COLOUR_DEFAULTS=Object.freeze({
  foreground:'#f5bd4f',
  surface0:'#ffffff',
  surface1:'#dc4545',
  surface2:'#5ed46c',
  surface3:'#4a79e8'
});
const overlayColours={...OVERLAY_COLOUR_DEFAULTS};
let overlayColourObserver=null;

function validHexColour(v){return /^#[0-9a-f]{6}$/i.test(String(v||''));}
function loadOverlayColours(){
  try{
    const saved=JSON.parse(localStorage.getItem(OVERLAY_COLOUR_STORAGE)||'{}');
    for(const k of Object.keys(OVERLAY_COLOUR_DEFAULTS))if(validHexColour(saved[k]))overlayColours[k]=saved[k].toLowerCase();
  }catch(_e){}
}
function saveOverlayColours(){
  try{localStorage.setItem(OVERLAY_COLOUR_STORAGE,JSON.stringify(overlayColours));}catch(_e){}
}
function colourRgba(hex,a){
  const n=parseInt(String(hex).slice(1),16);
  return `rgba(${(n>>16)&255},${(n>>8)&255},${n&255},${a})`;
}
function compactColour(v){return String(v||'').toLowerCase().replace(/\s+/g,'');}
function remapLayerFillStyle(style){
  const s=compactColour(style);
  if(s==='#f5bd4f'||s==='rgb(245,189,79)')return overlayColours.foreground;
  if(s==='#dc4545'||s==='rgb(220,69,69)')return overlayColours.surface1;
  if(s==='#5ed46c'||s==='rgb(94,212,108)')return overlayColours.surface2;
  if(s==='#4a79e8'||s==='rgb(74,121,232)')return overlayColours.surface3;
  if(s==='rgba(255,255,255,0.15)'||s==='rgba(255,255,255,.15)')return colourRgba(overlayColours.surface0,.15);
  return style;
}
function installLayerFillColourBridge(){
  const proto=root.CanvasRenderingContext2D?.prototype;
  if(!proto||proto.__indyHeatOverlayColours025)return !!proto;
  const native=proto.fillRect;
  if(typeof native!=='function')return false;
  proto.__indyHeatOverlayColours025=true;
  proto.fillRect=function(x,y,w,h){
    if(this?.canvas?.id==='layerEditCanvas'){
      const before=this.fillStyle,mapped=remapLayerFillStyle(before);
      if(mapped!==before){
        this.fillStyle=mapped;
        try{return native.call(this,x,y,w,h);}finally{this.fillStyle=before;}
      }
    }
    return native.call(this,x,y,w,h);
  };
  return true;
}
function requestOverlayRedraw(){
  const opacity=$('opacity');
  if(opacity)opacity.dispatchEvent(new Event('input',{bubbles:true}));
}
function makeColourWheel(id,key,title){
  const input=document.createElement('input');
  input.type='color';input.id=id;input.className='overlayColourWheel';
  input.value=overlayColours[key];input.title=title;input.setAttribute('aria-label',title);
  input.dataset.overlayColourKey=key;
  input.addEventListener('pointerdown',e=>e.stopPropagation());
  input.addEventListener('click',e=>e.stopPropagation());
  input.addEventListener('input',()=>{
    if(validHexColour(input.value)){
      overlayColours[key]=input.value.toLowerCase();
      saveOverlayColours();syncLayerPaintSwatches();requestOverlayRedraw();
    }
  });
  return input;
}
function syncLayerPaintSwatches(){
  const map={
    '.paint-fg':'foreground',
    '.paint-normal':'surface0',
    '.paint-edge':'surface1',
    '.paint-slowA':'surface2',
    '.paint-slowB':'surface3'
  };
  for(const [sel,key] of Object.entries(map))document.querySelectorAll(sel).forEach(e=>e.style.background=overlayColours[key]);
}
function wrapSurfaceLabelText(label){
  let span=label.querySelector('.overlayColourLabelText');
  if(span)return span;
  span=document.createElement('span');span.className='overlayColourLabelText';
  const nodes=[...label.childNodes].filter(n=>n.nodeType===Node.TEXT_NODE&&n.textContent.trim());
  if(nodes.length){
    span.textContent=nodes.map(n=>n.textContent).join(' ').trim();
    for(const n of nodes)n.remove();
  }
  label.appendChild(span);
  return span;
}
function installOverlayColourControls(){
  const mask=$('layerShowMask');
  const surfaceChecks=[...document.querySelectorAll('.surfaceClass')];
  if(!mask||surfaceChecks.length<4)return false;

  if(!document.getElementById('indyheatOverlayColourStyle025')){
    const style=document.createElement('style');style.id='indyheatOverlayColourStyle025';
    style.textContent=`
      .overlayColourWheel{width:21px!important;height:21px!important;min-width:21px!important;padding:0!important;border:1px solid #687282!important;border-radius:50%!important;background:transparent!important;overflow:hidden;cursor:pointer;box-sizing:border-box}
      .overlayColourWheel::-webkit-color-swatch-wrapper{padding:0}
      .overlayColourWheel::-webkit-color-swatch{border:0;border-radius:50%}
      .overlayColourWheel::-moz-color-swatch{border:0;border-radius:50%}
      .surfaceClassColourLabel{display:grid!important;grid-template-columns:auto minmax(0,1fr) auto;gap:7px;align-items:center}
      .surfaceClassColourLabel .overlayColourLabelText{min-width:0}
    `;
    document.head.appendChild(style);
  }

  const maskRow=mask.closest('.layerControlRow')||mask.parentElement;
  if(maskRow&&!$('overlayColourForeground')){
    maskRow.style.gridTemplateColumns='auto minmax(0,1fr) auto';
    maskRow.appendChild(makeColourWheel('overlayColourForeground','foreground','Foreground overlay colour'));
  }

  for(const c of surfaceChecks){
    const n=Number(c.dataset.class);if(n<0||n>3)continue;
    const label=c.closest('label');if(!label)continue;
    label.classList.add('surfaceClassColourLabel');
    wrapSurfaceLabelText(label);
    const id=`overlayColourSurface${n}`;
    if(!$(id))label.appendChild(makeColourWheel(id,`surface${n}`,`Surface class ${n} overlay colour`));
  }

  syncLayerPaintSwatches();
  const paintHost=$('layerPaintChoices');
  if(paintHost&&!overlayColourObserver&&typeof MutationObserver!=='undefined'){
    overlayColourObserver=new MutationObserver(syncLayerPaintSwatches);
    overlayColourObserver.observe(paintHost,{childList:true,subtree:true});
  }
  return true;
}
loadOverlayColours();

/* -------------------------------------------------------------------------
 * Race lap authoring: slider, 1..20.
 *
 * Keep the existing #raceLaps element so all existing authoring/apply guards
 * remain attached. Only its presentation changes from numeric entry to range.
 * ---------------------------------------------------------------------- */
function lapSliderValue(){
  const e=$('raceLaps'),out=$('raceLapsSliderValue');
  if(!e||!out)return false;
  let v=Math.round(Number(e.value));
  if(!Number.isFinite(v))v=1;
  v=Math.max(1,Math.min(20,v));
  if(String(v)!==e.value)e.value=String(v);
  out.value=String(v);
  out.textContent=String(v);
  out.setAttribute('aria-label',`${v} laps`);
  return true;
}
function installLapSlider(){
  const e=$('raceLaps');
  if(!e)return false;

  e.type='range';
  e.min='1';
  e.max='20';
  e.step='1';
  e.title='Authored custom range: 1–20. Lap 20 is displayed as F during gameplay.';
  e.setAttribute('aria-label','Race laps');

  let out=$('raceLapsSliderValue');
  if(!out){
    const row=document.createElement('div');
    row.className='raceLapSliderRow';
    const parent=e.parentNode;
    if(parent){
      parent.insertBefore(row,e);
      row.appendChild(e);
      out=document.createElement('output');
      out.id='raceLapsSliderValue';
      out.className='raceLapSliderValue';
      out.htmlFor='raceLaps';
      row.appendChild(out);
    }
  }

  if(!document.getElementById('indyheatLapSliderStyle023')){
    const style=document.createElement('style');
    style.id='indyheatLapSliderStyle023';
    style.textContent=`
      .raceLapSliderRow{display:flex;align-items:center;gap:8px;width:100%}
      .raceLapSliderRow #raceLaps{flex:1 1 auto;width:auto!important;min-width:0;margin:0}
      .raceLapSliderValue{flex:0 0 2ch;min-width:2ch;text-align:right;font-weight:700;color:#e3e7ec;font-variant-numeric:tabular-nums}
    `;
    document.head.appendChild(style);
  }

  if(!e.dataset.v023LapSlider){
    e.dataset.v023LapSlider='1';
    e.addEventListener('input',lapSliderValue);
    e.addEventListener('change',lapSliderValue);

    $('trackSelect')?.addEventListener('change',()=>setTimeout(lapSliderValue,0));
    document.addEventListener('indyheat-race-setup-capture',()=>setTimeout(lapSliderValue,0));
    document.addEventListener('click',ev=>{
      const id=ev.target?.closest?.('button')?.id;
      if(id==='raceApply'||id==='raceRevert')setTimeout(lapSliderValue,0);
    });
  }

  return lapSliderValue();
}

function reorderModes(){
  const host=$('layerModeButtons');
  if(!host)return false;

  const wanted=MODE_ORDER.filter(id=>{
    const b=$(id);
    return !!(b&&b.parentNode===host);
  });
  const current=[...host.children]
    .map(el=>el.id)
    .filter(id=>wanted.includes(id));

  const same=current.length===wanted.length&&current.every((id,i)=>id===wanted[i]);
  if(!same){
    for(const id of wanted){
      const b=$(id);
      if(id==='layerEditMini')b.textContent='MiniMap';
      host.appendChild(b);
    }
  }else{
    const mini=$('layerEditMini');
    if(mini&&mini.textContent!=='MiniMap')mini.textContent='MiniMap';
  }
  return MODE_ORDER.every(id=>!!$(id));
}

function installModeOrder(){
  const host=$('layerModeButtons');
  if(!host)return false;

  // Important: do NOT observe childList mutations here. Reordering existing
  // buttons itself mutates childList; observing and re-appending those nodes can
  // create an event loop that starves the browser UI.
  reorderModes();

  if(!host.dataset.v0196ModeOrder){
    host.dataset.v0196ModeOrder='1';

    // v0.19.5 also reorders after mode clicks. Queue ours afterwards so the
    // project-approved order is the final DOM order without a MutationObserver.
    host.addEventListener('click',()=>setTimeout(reorderModes,0));
  }
  return true;
}

/* -------------------------------------------------------------------------
 * Lap tower: global capture drag.
 * ---------------------------------------------------------------------- */
function raceActive(){
  const pane=$('raceSetupPane'),button=$('layerEditRaceSetup');
  return !!(pane&&!pane.hidden&&button?.classList.contains('active'));
}
function eventGamePoint(e,{allowOutside=false}={}){
  const view=$('view');
  if(!view)return null;
  const r=view.getBoundingClientRect();
  if(!r.width||!r.height)return null;
  const inside=e.clientX>=r.left&&e.clientX<=r.right&&e.clientY>=r.top&&e.clientY<=r.bottom;
  if(!inside&&!allowOutside)return null;
  return {
    x:(e.clientX-r.left)*TRACK_W/r.width,
    y:(e.clientY-r.top)*TRACK_H/r.height,
    inside
  };
}
function hudBounds(p){
  const x=Number(p?.lapDisplayX)||0,y=Number(p?.lapDisplayY)||0;
  // Generous visible-HUD rectangle: four current-lap cells, total-laps object,
  // timer digits and a few pixels of grab margin.
  return {x0:x-18,y0:y-8,x1:x+26,y1:y+66};
}
function pointInHud(q,p){
  if(!q||!p)return false;
  const b=hudBounds(p);
  return q.x>=b.x0&&q.x<=b.x1&&q.y>=b.y0&&q.y<=b.y1;
}
function redrawHud(){
  const opacity=$('opacity');
  if(opacity)opacity.dispatchEvent(new Event('input',{bubbles:true}));
}
function writeHud(x,y){
  const P=packageTools();
  if(!P)return false;
  x=Math.round(x);y=Math.round(y);
  let wrote=false;
  for(const m of models()){
    const r=recordFor(m);
    if(!r)continue;
    P.writePresentation(m.main,r.offset,{lapDisplayX:x,lapDisplayY:y});
    wrote=true;
  }
  if(!wrote)return false;
  const X=$('circuitHudX'),Y=$('circuitHudY');
  if(X)X.value=String(x);
  if(Y)Y.value=String(y);
  redrawHud();
  return true;
}
function finishHudDrag(e){
  if(!hudDrag)return;
  if(e&&e.pointerId!=null&&hudDrag.pointerId!==e.pointerId)return;
  try{hudDrag.capture?.releasePointerCapture?.(hudDrag.pointerId);}catch(_e){}
  hudDrag=null;
  document.documentElement.classList.remove('indyheatHudDragging');
  redrawHud();
}
function installHudDrag(){
  if(document.documentElement.dataset.v0196HudDrag)return true;
  document.documentElement.dataset.v0196HudDrag='1';

  // Retire the v0.19.5 DOM hit target. It is no longer part of input routing.
  const style=document.createElement('style');
  style.id='indyheatHudCaptureStyle0196';
  style.textContent=`
    #editorFixHudDragHit194{pointer-events:none!important}
    html.indyheatHudDragging,html.indyheatHudDragging *{cursor:grabbing!important}
  `;
  document.head.appendChild(style);

  document.addEventListener('pointerdown',e=>{
    if(e.button!==0||!raceActive())return;
    const q=eventGamePoint(e),p=currentPresentation();
    if(!q||!p||!pointInHud(q,p))return;

    // Capture before raceSetupCanvas, layer canvas or any future overlay can
    // claim the gesture.
    e.preventDefault();
    e.stopImmediatePropagation();

    hudDrag={
      pointerId:e.pointerId,
      offsetX:q.x-(Number(p.lapDisplayX)||0),
      offsetY:q.y-(Number(p.lapDisplayY)||0),
      capture:e.target instanceof Element?e.target:null
    };
    try{hudDrag.capture?.setPointerCapture?.(e.pointerId);}catch(_e){}
    document.documentElement.classList.add('indyheatHudDragging');
  },true);

  window.addEventListener('pointermove',e=>{
    if(hudDrag&&hudDrag.pointerId===e.pointerId){
      const q=eventGamePoint(e,{allowOutside:true});
      if(!q)return;
      e.preventDefault();
      e.stopImmediatePropagation();
      writeHud(q.x-hudDrag.offsetX,q.y-hudDrag.offsetY);
      return;
    }

    // Cursor feedback is based on coordinates rather than event target too.
    if(!raceActive())return;
    const q=eventGamePoint(e),p=currentPresentation(),view=$('view');
    if(view)view.style.cursor=(q&&p&&pointInHud(q,p))?'grab':'';
  },true);

  window.addEventListener('pointerup',e=>{
    if(!hudDrag||hudDrag.pointerId!==e.pointerId)return;
    e.preventDefault();
    e.stopImmediatePropagation();
    finishHudDrag(e);
  },true);
  window.addEventListener('pointercancel',finishHudDrag,true);
  window.addEventListener('blur',()=>finishHudDrag(null));

  return true;
}

/* -------------------------------------------------------------------------
 * Explicit race -> Garage palette lookup for "From backdrop".
 * ---------------------------------------------------------------------- */
function reduceBackdropWithLookup(source){
  const out=new Uint8Array(PREVIEW_W*PREVIEW_H);
  for(let dy=0;dy<PREVIEW_H;dy++){
    const sy0=Math.floor(dy*TRACK_GAME_H/PREVIEW_H);
    const sy1=Math.max(sy0+1,Math.floor((dy+1)*TRACK_GAME_H/PREVIEW_H));
    for(let dx=0;dx<PREVIEW_W;dx++){
      const sx0=Math.floor(dx*TRACK_W/PREVIEW_W);
      const sx1=Math.max(sx0+1,Math.floor((dx+1)*TRACK_W/PREVIEW_W));
      const counts=new Uint16Array(32);

      // Remap every sampled race pixel first. Repeated destination colours in
      // the supplied lookup deliberately combine before the area-mode choice.
      for(let sy=sy0;sy<sy1;sy++)for(let sx=sx0;sx<sx1;sx++){
        const raceIndex=source[sy*TRACK_W+sx]&31;
        counts[RACE_TO_GARAGE[raceIndex]]++;
      }

      let best=0,bestN=-1;
      for(let i=0;i<32;i++){
        if(counts[i]>bestN){bestN=counts[i];best=i;}
      }
      out[dy*PREVIEW_W+dx]=best;
    }
  }
  return out;
}
function setMiniStatus(text){
  const e=$('circuitAuxStatusMini');
  if(e)e.textContent=text;
}
function chooseUnusedMiniTransparency(pixels,currentTransparent){
  const used=new Set(pixels);if(!used.has(currentTransparent))return currentTransparent;
  for(let i=0;i<32;i++)if(!used.has(i))return i;
  throw new Error('The generated MiniMap uses all 32 palette indices; no unused transparency index is available.');
}
function applyExplicitPaletteMap(){
  const P=packageTools(),T=tools(),model=resourceModel(),r=recordFor(model);
  if(!P||!T||!model||!r)return false;
  try{
    const bg=model.getResource(r.baseResourceId);
    const TB=root.IndyHeatTrackBackdropTools;
    const source=TB?.decodeTrackPlanar
      ? TB.decodeTrackPlanar(bg.data)
      : T.decodePlanar(bg.data,TRACK_W,TRACK_H,5,0);
    const pixels=reduceBackdropWithLookup(source);

    for(const m of models()){
      const mr=recordFor(m);if(!mr)continue;
      const q=P.resolvePreviewResource(m,mr),decoded=P.decodePreviewBob(q.resource.data);
      const transparent=chooseUnusedMiniTransparency(pixels,decoded.transparent);
      q.resource.data.set(P.encodePreviewPixels(pixels,q.resource.data,transparent));
    }

    setTimeout(()=>$('layerEditMini')?.click(),0);
    return true;
  }catch(err){
    const top=$('circuitPackageTopStatus');if(top){top.textContent=`ERROR: ${err.message}`;top.classList.add('bad');}
    return false;
  }
}
function installPaletteMap(){
  const b=$('circuitPreviewFromBackdrop');
  if(!b)return false;
  if(b.dataset.v0196PaletteMap)return true;
  b.dataset.v0196PaletteMap='1';

  // circuit-package.js registered its own handler when it created the button.
  // Our later listener therefore runs after it. This intentionally preserves
  // its existing package-aware Undo snapshot, then replaces the generated
  // pixels with the authoritative lookup result.
  b.addEventListener('click',()=>setTimeout(applyExplicitPaletteMap,0));

  return true;
}


/* -------------------------------------------------------------------------
 * Gasoline Alley circuit-name authoring.
 *
 * The game already renders race+$70..+$81. Keep the proven $68
 * race_setup.bin unchanged and carry the authored 18-byte field in the
 * optional circuit_xx/name.bin package sidecar instead. Authored names are
 * package metadata keyed by circuit number so shared retail host templates
 * are not mutated when switching custom packages.
 * ---------------------------------------------------------------------- */
function currentCircuitIndex(){
  const n=Number($('circuitNumber')?.value);
  return Number.isInteger(n)&&n>=0&&n<=99?n:trackIndex();
}
function nameBytesFor(model,record){
  if(!model||!record)return null;
  return model.main.slice(record.offset+NAME_OFFSET,record.offset+NAME_OFFSET+NAME_SIZE);
}
function currentNameBytes(){
  const key=currentCircuitIndex(),authored=authoredNames.get(key);
  if(authored)return authored.slice();
  const m=primaryModel(),r=recordFor(m),b=nameBytesFor(m,r);
  if(!b||b.length!==NAME_SIZE)throw new Error('Current circuit name field is unavailable');
  return b;
}
function currentName(){return decodeNameBytes(currentNameBytes());}
function setVersion(){
  const h=document.querySelector('header h1');
  if(h)h.textContent='Indy Heat Amiga — Circuit Editor v0.26';
  document.title='Indy Heat Amiga – Circuit Editor v0.26';
}
function setRaceStatus(text){const e=$('raceSetupStatus');if(e)e.textContent=text;}
function setTopStatus(text,bad=false){
  const e=$('circuitPackageTopStatus');if(!e)return;
  e.textContent=text;e.classList.toggle('bad',!!bad);
}
function updateCounter(){
  const input=$('raceCircuitName'),out=$('raceCircuitNameCount');if(!input||!out)return;
  out.textContent=`${input.value.length}/${NAME_DISPLAY_SIZE}`;
}
function syncNameUi(force=false){
  const input=$('raceCircuitName');if(!input)return false;
  if(!force&&document.activeElement===input&&input.dataset.editing==='1')return true;
  try{input.value=currentName();}catch(_e){return false;}
  input.dataset.editing='';updateCounter();
  return true;
}
function installNameUi(){
  const grid=$('raceLaps')?.closest('.raceSetupGrid');
  if(!grid)return false;
  if(!$('raceCircuitName')){
    const label=document.createElement('label');label.className='raceSetupWide';
    label.innerHTML=`Circuit name <span style="display:flex;gap:7px;align-items:center"><input id="raceCircuitName" type="text" maxlength="${NAME_DISPLAY_SIZE}" autocomplete="off" spellcheck="false" title="Gasoline Alley circuit name; 1–${NAME_DISPLAY_SIZE} printable ASCII characters"><output id="raceCircuitNameCount" style="min-width:4.5ch;text-align:right"></output></span><span class="muted" style="font-size:10px;line-height:1.25">Displayed on Gasoline Alley. Exported as the optional 18-byte name.bin package sidecar.</span>`;
    grid.insertBefore(label,grid.firstChild);
    const input=$('raceCircuitName');
    input.addEventListener('input',()=>{input.dataset.editing='1';updateCounter();});
  }
  const apply=$('raceApply');
  if(apply&&!apply.dataset.v026CircuitName){
    apply.dataset.v026CircuitName='1';
    apply.addEventListener('click',e=>{
      try{
        const bytes=encodeNameBytes($('raceCircuitName').value);
        authoredNames.set(currentCircuitIndex(),bytes);
        $('raceCircuitName').dataset.editing='';
      }catch(err){
        e.preventDefault();e.stopImmediatePropagation();setRaceStatus(`ERROR: ${err.message}`);
      }
    },true);
    apply.addEventListener('click',()=>setTimeout(()=>syncNameUi(true),0));
  }
  const revert=$('raceRevert');
  if(revert&&!revert.dataset.v026CircuitName){
    revert.dataset.v026CircuitName='1';
    revert.addEventListener('click',()=>{
      authoredNames.delete(currentCircuitIndex());
      setTimeout(()=>syncNameUi(true),0);
    },true);
  }
  if(!$('trackSelect')?.dataset.v026CircuitName){
    const sel=$('trackSelect');if(sel){sel.dataset.v026CircuitName='1';sel.addEventListener('change',()=>setTimeout(()=>syncNameUi(true),0));}
  }
  if(!$('circuitNumber')?.dataset.v026CircuitName){
    const n=$('circuitNumber');if(n){n.dataset.v026CircuitName='1';n.addEventListener('change',()=>setTimeout(()=>syncNameUi(true),0));}
  }
  syncNameUi();
  return true;
}

function installNameImport(){
  const input=$('circuitPackageInput'),P=packageTools();if(!input||!P)return false;
  if(input.dataset.v026CircuitName)return true;
  input.dataset.v026CircuitName='1';
  input.addEventListener('change',e=>{
    const file=e.target.files?.[0];if(!file)return;
    (async()=>{
      try{
        const entries=P.readZipStore(new Uint8Array(await file.arrayBuffer()));
        let circuitIndex=null,hit=null;
        for(const [name,data] of entries){
          const root=/^circuit_(\d{2})\//.exec(name);if(root&&circuitIndex==null)circuitIndex=Number(root[1]);
          const m=/^circuit_(\d{2})\/name\.bin$/.exec(name);
          if(m){hit={circuitIndex:Number(m[1]),bytes:data};break;}
        }
        if(!hit){if(circuitIndex!=null)authoredNames.delete(circuitIndex);setTimeout(()=>syncNameUi(true),50);return;}
        if(hit.bytes.length!==NAME_SIZE)throw new Error(`name.bin must be exactly $${NAME_SIZE.toString(16).toUpperCase()} bytes`);
        if(hit.bytes[NAME_DISPLAY_SIZE]!==0)throw new Error('name.bin byte 17 must be the terminating NUL');
        authoredNames.set(hit.circuitIndex,hit.bytes.slice());
        setTimeout(()=>syncNameUi(true),50);
      }catch(err){setTopStatus(`ERROR: ${err.message}`,true);}
    })();
  },true);
  return true;
}

function installNameExport(){
  const button=$('circuitPackageZip'),P=packageTools();if(!button||!P)return false;
  if(button.dataset.v026CircuitName)return true;
  button.dataset.v026CircuitName='1';
  button.addEventListener('click',()=>{
    if(zipHookBusy)return;
    zipHookBusy=true;
    const nativeCreate=URL.createObjectURL;
    const nativeClick=HTMLAnchorElement.prototype.click;
    let zipBlob=null,downloadName='';
    URL.createObjectURL=function(blob){
      if(!zipBlob&&blob instanceof Blob&&blob.type==='application/zip')zipBlob=blob;
      return nativeCreate.call(URL,blob);
    };
    HTMLAnchorElement.prototype.click=function(){
      if(zipBlob&&/\.zip$/i.test(this.download||'')){downloadName=this.download;return;}
      return nativeClick.call(this);
    };
    setTimeout(async()=>{
      URL.createObjectURL=nativeCreate;
      HTMLAnchorElement.prototype.click=nativeClick;
      zipHookBusy=false;
      if(!zipBlob)return;
      try{
        const original=new Uint8Array(await zipBlob.arrayBuffer());
        const nameBytes=currentNameBytes();
        const circuitIndex=currentCircuitIndex();
        const zip=addNameFileToZipBytes(P,original,circuitIndex,nameBytes);
        const blob=new Blob([zip],{type:'application/zip'});
        const a=document.createElement('a');
        a.href=nativeCreate.call(URL,blob);
        a.download=downloadName||`${P.circuitFolder(circuitIndex)}.zip`;
        nativeClick.call(a);
        setTimeout(()=>URL.revokeObjectURL(a.href),1000);
        setTopStatus(`${P.circuitFolder(circuitIndex)} exported with 9 runtime files including name.bin.`);
      }catch(err){setTopStatus(`ERROR: ${err.message}`,true);}
    },0);
  },true);
  return true;
}

function tick(){
  setVersion();
  installModeOrder();
  const colourBridgeReady=installLayerFillColourBridge();
  const colourControlsReady=installOverlayColourControls();
  installLapSlider();
  installHudDrag();
  installPaletteMap();
  const nameUiReady=installNameUi();
  const nameImportReady=installNameImport();
  const nameExportReady=installNameExport();

  return !!(
    colourBridgeReady&&colourControlsReady&&
    nameUiReady&&nameImportReady&&nameExportReady&&
    tools()&&packageTools()&&capture()&&
    $('layerModeButtons')&&$('layerEditRecovery')&&$('layerEditRaceSetup')&&
    $('circuitPreviewFromBackdrop')
  );
}
function boot(){
  let tries=0;
  tick();
  bootTimer=setInterval(()=>{
    tries++;
    if(tick()||tries>400){
      clearInterval(bootTimer);
      bootTimer=null;
    }
  },50);

  document.addEventListener('indyheat-race-setup-capture',()=>setTimeout(()=>syncNameUi(true),0));

  // Keep the final order/version after the older corrective layer's delayed
  // startup timers have completed.
  setTimeout(()=>{setVersion();reorderModes();},1000);
  setTimeout(()=>{setVersion();reorderModes();},3000);
}
if(document.readyState==='loading')
  document.addEventListener('DOMContentLoaded',()=>setTimeout(boot,0),{once:true});
else
  setTimeout(boot,0);

})(typeof globalThis!=='undefined'?globalThis:this);
