# Indy Heat original resource assets — no installation required

**Open `wiki/data/Generate-Wiki-Assets.html` in your browser.** Keep it inside your normal repository mirror so the editor decoder scripts remain accessible under `app/`.

1. Select `whdload/data/Disk.1` (901,120 bytes).
2. Select all existing `wiki/data/audio/*.bin` files (recommended; select the complete folder contents).
3. Click **Generate ZIP from original data**. Your browser will download a ZIP that contains the completed Wiki documentation and all generated assets.
4. Unzip the generated archive at the repository root, preserving the `wiki/data/` folder structure. No existing resource needs to be deleted.

The browser exporter creates PNGs of original screens, retail tracks, MiniMaps, and contact sheets of 15 object/sprite banks, plus 29 individual resource `$12` frames, raw decompressed resource payloads where supported, physical packed sector fallbacks where the wrapper is undecoded, and WAV previews of the signed 8-bit PCM sounds. Original ChipTracker music and raw sample BINs are preserved byte-for-byte. Nominal WAV playback Hz is calculated from the original PAL Amiga Paula period, which may change dynamically in-game.

It works offline with the editor's existing decoders; **Node, Python, npm and the command line are not required**.
