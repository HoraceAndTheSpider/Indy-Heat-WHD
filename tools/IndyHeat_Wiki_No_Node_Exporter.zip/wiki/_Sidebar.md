**Indy Heat reverse engineering**

- [[Home]]

**Game / data reference**
- [[Disk Image, Loader and Runtime Resource Map]]
- [[Original Disk.1 Resource Schedule]]
- [[Presentation and Graphics Resource Files]]
- [[Audio Resources and Formats]]
- [[Track Data and Runtime Setup]]
- [[Waypoint, AI and Car Behaviour]]
- [[Race, Car and Pit Runtime Structures]]
- [[Player, Driver and Car Data Structures]]
- [[Race Presentation and Graphics Resources]]
- [[WHDLoad Runtime Overrides and Custom Track Loading]]

**Editor reference**
- [[Circuit Editor Operations]]
- [[Editor and Track Package Workflow]]
- [[Special-Functions-Architecture-and-Rules]]
- [[Special-Functions-Current-State]]
- [[October 2026 Development Status]]

**Open work (single page)**
- [[Further Investigation]]
