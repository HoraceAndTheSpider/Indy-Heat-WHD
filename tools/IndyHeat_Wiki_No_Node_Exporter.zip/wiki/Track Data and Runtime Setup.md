# Track Data and Runtime Setup

Updated: 8 October 2026 (resource hyperlinks and current compact setup)

This page is the quick reference for physical circuit templates and the main per-track resources/race setup data. Loader details are on [[Disk Image, Loader and Runtime Resource Map]]; routes and race structures have their own dedicated pages.

## Physical templates

| ID | Circuit | Direction |
|---:|---|---|
| 1 | Illinois | Anticlockwise |
| 2 | New Jersey | Anticlockwise |
| 3 | West Canada | Clockwise |
| 4 | South California | Clockwise |
| 5 | East Canada | Clockwise |
| 6 | Indianapolis | Anticlockwise |
| 7 | Michigan | Anticlockwise |
| 8 | Colorado | Clockwise |
| 9 | North California | Anticlockwise |
| 10 | Kentucky | Clockwise |

Event 11 reuses Indianapolis.

Retail championship records:

```text
first race record  $5902
record advance     +$82
end/sentinel       $5E98
active pointer     A6+$3DD6
retail count       11
```

In current custom playlist mode the ten retail physical circuits remain immutable source assets; retail events use their restored native `$82` race records. Custom `circuit_10..99` events use an independently rebuilt active `$82` record at `$95600`, with explicit package resources in the fixed high-memory arena. Retail-template inference/copying for custom circuits was removed by WHDLoad test 50. See [[WHDLoad Runtime Overrides and Custom Track Loading]].

## Track resources

Canonical base resource IDs:

```text
39 3D 41 45 49 4D 5A 5E 62 66
```

Each physical template owns four consecutive resources:

```text
base+0  320×256, 5-plane Backdrop/background
base+1  320×256, 1bpp foreground/occlusion bitmap
base+2  $1180 packed 2bpp Surface map = 160×112 logical cells
base+3  $0460 Recovery heading field = 40×28 bytes
```

Spatial scale:

```text
Surface cell    2×2 gameplay pixels
Recovery cell   8×8 gameplay pixels
```

Surface classes:

```text
0  Normal
1  Edge / collision response
2  Slowdown A
3  Slowdown B
```

The Recovery byte is the proved recovery/collision heading for that 8×8 cell. It is not the normal route-driving heading source for the `$38` car graphics.

## Original circuit files (direct views and source data)

Each cell links separately to a translated PNG inspection view and to the **unaltered decompressed resource bytes**. The Backdrop is a 320×256 five-plane picture; Foreground is a one-bit mask; Surface is a packed two-bit class map; Recovery is a grid of original directional bytes. The preview PNGs are diagnostic renderings and do not replace raw asset data. The single cross-resource authority remains [[Original Disk.1 Resource Schedule]].

| Circuit | Backdrop | Foreground | Surface | Recovery |
|---|---|---|---|---|
| Illinois | [$39 PNG](data/graphics/resource_39.png) · [BIN](data/raw/resource_39.bin) | [$3A PNG](data/graphics/resource_3A.png) · [BIN](data/raw/resource_3A.bin) | [$3B PNG](data/graphics/resource_3B.png) · [BIN](data/raw/resource_3B.bin) | [$3C PNG](data/graphics/resource_3C.png) · [BIN](data/raw/resource_3C.bin) |
| New Jersey | [$3D PNG](data/graphics/resource_3D.png) · [BIN](data/raw/resource_3D.bin) | [$3E PNG](data/graphics/resource_3E.png) · [BIN](data/raw/resource_3E.bin) | [$3F PNG](data/graphics/resource_3F.png) · [BIN](data/raw/resource_3F.bin) | [$40 PNG](data/graphics/resource_40.png) · [BIN](data/raw/resource_40.bin) |
| West Canada | [$41 PNG](data/graphics/resource_41.png) · [BIN](data/raw/resource_41.bin) | [$42 PNG](data/graphics/resource_42.png) · [BIN](data/raw/resource_42.bin) | [$43 PNG](data/graphics/resource_43.png) · [BIN](data/raw/resource_43.bin) | [$44 PNG](data/graphics/resource_44.png) · [BIN](data/raw/resource_44.bin) |
| South California | [$45 PNG](data/graphics/resource_45.png) · [BIN](data/raw/resource_45.bin) | [$46 PNG](data/graphics/resource_46.png) · [BIN](data/raw/resource_46.bin) | [$47 PNG](data/graphics/resource_47.png) · [BIN](data/raw/resource_47.bin) | [$48 PNG](data/graphics/resource_48.png) · [BIN](data/raw/resource_48.bin) |
| East Canada | [$49 PNG](data/graphics/resource_49.png) · [BIN](data/raw/resource_49.bin) | [$4A PNG](data/graphics/resource_4A.png) · [BIN](data/raw/resource_4A.bin) | [$4B PNG](data/graphics/resource_4B.png) · [BIN](data/raw/resource_4B.bin) | [$4C PNG](data/graphics/resource_4C.png) · [BIN](data/raw/resource_4C.bin) |
| Indianapolis | [$4D PNG](data/graphics/resource_4D.png) · [BIN](data/raw/resource_4D.bin) | [$4E PNG](data/graphics/resource_4E.png) · [BIN](data/raw/resource_4E.bin) | [$4F PNG](data/graphics/resource_4F.png) · [BIN](data/raw/resource_4F.bin) | [$50 PNG](data/graphics/resource_50.png) · [BIN](data/raw/resource_50.bin) |
| Michigan | [$5A PNG](data/graphics/resource_5A.png) · [BIN](data/raw/resource_5A.bin) | [$5B PNG](data/graphics/resource_5B.png) · [BIN](data/raw/resource_5B.bin) | [$5C PNG](data/graphics/resource_5C.png) · [BIN](data/raw/resource_5C.bin) | [$5D PNG](data/graphics/resource_5D.png) · [BIN](data/raw/resource_5D.bin) |
| Colorado | [$5E PNG](data/graphics/resource_5E.png) · [BIN](data/raw/resource_5E.bin) | [$5F PNG](data/graphics/resource_5F.png) · [BIN](data/raw/resource_5F.bin) | [$60 PNG](data/graphics/resource_60.png) · [BIN](data/raw/resource_60.bin) | [$61 PNG](data/graphics/resource_61.png) · [BIN](data/raw/resource_61.bin) |
| North California | [$62 PNG](data/graphics/resource_62.png) · [BIN](data/raw/resource_62.bin) | [$63 PNG](data/graphics/resource_63.png) · [BIN](data/raw/resource_63.bin) | [$64 PNG](data/graphics/resource_64.png) · [BIN](data/raw/resource_64.bin) | [$65 PNG](data/graphics/resource_65.png) · [BIN](data/raw/resource_65.bin) |
| Kentucky | [$66 PNG](data/graphics/resource_66.png) · [BIN](data/raw/resource_66.bin) | [$67 PNG](data/graphics/resource_67.png) · [BIN](data/raw/resource_67.bin) | [$68 PNG](data/graphics/resource_68.png) · [BIN](data/raw/resource_68.bin) | [$69 PNG](data/graphics/resource_69.png) · [BIN](data/raw/resource_69.bin) |

These files are reproduced from original `Disk.1` by the [browser-based Wiki asset exporter](data/Generate-Wiki-Assets.html) (no npm dependencies). The Wiki links become live when the generated files have been added to the Wiki data folder.

## Race-record resource links

The four longs at race offsets:

```text
+$36
+$3A
+$3E
+$42
```

point at `+2.w` inside the four consecutive resource-directory entries for the selected track. This links a race record directly to its Backdrop/Foreground/Surface/Recovery set.

## Current `$76` race setup package

The current editor uses the `$76`-byte `race_setup.bin`, retaining the existing `$74`-byte fields and appending the test-52 lower-HUD word. It keeps the established compact race/pit layout, the four proved race-level Pitlane controls, and appends the explicit Route A/B starting-assignment polarity:

```text
+00..+01  race+$28.w laps
+02..+05  race+$5C/+5E flag position
+06..+0F  race+$62/+66 start/grid origin + race+$6A Grid X direction
+10..+67  four raw $16-byte pit records
+68..+69  race+$2C.w pit-pickup centre X
+6A..+6B  race+$2E.w pit-pickup top Y
+6C..+6D  race+$30.w pit-pickup half-width
+6E..+6F  race+$60.w Pit approach Y
+70..+73 race+$6C.l Route A/B starting-assignment polarity
+74..+75  lower three-player HUD offset (word, 0..12 pixels)
```

The pickup height is fixed by the game at 30 screen pixels and is therefore not another package field. The later final-service checks — normally forward speed below `$0100`, plus fewer than 3 integer world-X units from the selected service X, together with existing state/timer gates — are also fixed engine behaviour rather than circuit data.

The editor can still import older `$68`, `$70` and `$74` packages for migration. Current export writes the explicit `$76` layout.

WHDLoad test 52 consumes the full `$76` setup for `circuit_10+`, including the four Pitlane controls, `race+$6C.l` and lower-HUD shift. Zero HUD shift restores retail constants. The pit block is reused from the already-loaded setup rather than reopening the file.

Exact consumers, retail values and the staged pit-entry behaviour are on [[Race, Car and Pit Runtime Structures]].

## Start/finish and lap progression

Do not treat the flag position or start-grid origin as the gameplay lap-counting line.

The current disassembly evidence shows that human lap progression is driven by waypoint progress/sequence wrapping. The flag at `race+$5C/+5E` is presentation position; start data at `+$62/+66` places the grid and `+$6A` supplies the settled Grid X direction (`+X/-X`).

The `+$2C/+2E/+30` rectangle is the **pit-pickup/acquisition** region, not a lap checkpoint. `+$60` is the shared Pit approach Y used with each car's own service X after acquisition.

See [[Waypoint, AI and Car Behaviour]] for the established sequence-wrap mechanism.

## Regional maps

Runtime replacement is proved through resource [`$16` (original BIN)](data/raw/resource_16.bin), frame payload at `+$177C`, size `$093A`.

Known map IDs:

```text
0 USA
1 World
2 North America
3 South America
4 Europe
5 Africa
6 Asia
7 Australasia
```

The earlier runtime test selecting map ID 4 visibly displayed Europe in game.

## Lap range

Earlier work established that retail live values immediately above lap 12 are special states. Custom mode relocates those states and the currently supported complete race-length contract is:

```text
1..19  numeric current lap
20     final lap shown as retail F
```

Do not advertise 21–99 as gameplay-supported merely because the total-lap compositor can draw larger two-digit values.

## Custom circuit staging

The custom runtime retains fixed high-memory Backdrop, Foreground, Surface, Recovery, preview, route and pit slots and uses a reusable active `$82` race record at `$95600`. Built-in circuits can point from that active record to their original resident assets; custom circuits replace/repoint the active assets on demand. The complete map is on [[WHDLoad Runtime Overrides and Custom Track Loading]].
