# Audio Resources and Formats

Updated: 8 October 2026 (Wiki asset links). This page records original storage formats, the project owner’s **17 auditory-confirmed sound identities**, and targeted original-game-code evidence for the **three provisional identities**. See [[Original Disk.1 Resource Schedule]] for the complete directory, sizes and indexed extraction links.

## Confirmed music

Two distinct game music resources have been extracted and identified as **ChipTracker-format music**:

| Resource | Label found in data | Unpacked bytes | Original ChipTracker file | WAV | Interpretation |
|---|---|---:|---|---|---|
| `$01` | `BIGRUN` | 182,004 | [BIN](data/audio/resource_01_BIGRUN.bin) | Not rendered (ChipTracker) | Main music |
| `$51` | `BIGRUNHISCORE` | 26,308 | [BIN](data/audio/resource_51_BIGRUNHISCORE.bin) | Not rendered (ChipTracker) | High-score music |

The ChipTracker identity and the successful extraction are confirmed project findings, **not** a proposal to rerun disk-wide audio-format research. A source-compatible renderer/replayer may be investigated independently if an editor needs playback. Do not relabel these two resources as unidentified tracker/module candidates.

## Confirmed sound samples

Resources **`$24..$37` (20 total)** are the game's original sound-effect family. The moved `wiki/data/audio/resource_XX.bin` files are **raw signed 8-bit mono PCM sample data of the kind stored as the BODY portion of an Amiga 8SVX sample, without an 8SVX/FORM header**. They are **not** complete IFF `FORM 8SVX` files. Container/metadata are absent in those files; therefore an IFF player expecting `FORM`, `VHDR`, and `BODY` must add an appropriate wrapper or import them as raw PCM.

The project owner identified **17 of the 20 samples by listening** on 8 October 2026. `$30`, `$36` and `$37` remain provisional but have supporting original-code call sites documented below. Sound-list identities should not be confused with proof of every gameplay trigger. Actual output sample rates, looping/retrigger rules and the meaning of every playback-control parameter are still not established; **do not calculate sample rate from file length**. The original sound descriptor table is at runtime `$D0CC..$D149` and contains 21 six-byte entries for the 20 samples because `$30` appears twice with different playback parameters.

Original disk storage is **not uniformly the same as the extracted `.bin` format**. Some packed sound resources have a `KLUD` wrapper and an output length; others are handled through the normal Imploder path. The original PCM samples now live under **`wiki/data/audio/`**. Each has a neighbouring [WAV](#confirmed-sound-samples) playback preview generated from the same bytes. The original BIN is preserved unchanged; the WAV is a convenience translation rather than new source data. No extra resource-discovery pass is needed before identifying their audible content.

| Resource | Original sample bytes | Raw signed PCM | WAV playback preview | Identity | Evidence/status |
|---|---:|---|---|---|---|
| `$24` | 2,216 | [BIN](data/audio/resource_24.bin) | [WAV](data/audio/resource_24.wav) | Turbo Upgrade | Project owner (listening) |
| `$25` | 1,412 | [BIN](data/audio/resource_25.bin) | [WAV](data/audio/resource_25.wav) | Brake Upgrade | Project owner (listening) |
| `$26` | 7,040 | [BIN](data/audio/resource_26.bin) | [WAV](data/audio/resource_26.wav) | Tyres Upgrade | Project owner (listening) |
| `$27` | 3,650 | [BIN](data/audio/resource_27.bin) | [WAV](data/audio/resource_27.wav) | Crew Upgrade | Project owner (listening) |
| `$28` | 3,678 | [BIN](data/audio/resource_28.bin) | [WAV](data/audio/resource_28.wav) | MPG Upgrade | Project owner (listening) |
| `$29` | 6,050 | [BIN](data/audio/resource_29.bin) | [WAV](data/audio/resource_29.wav) | Engine Upgrade | Project owner (listening) |
| `$2A` | 676 | [BIN](data/audio/resource_2A.bin) | [WAV](data/audio/resource_2A.wav) | Start Next Race clicked | Project owner (listening) |
| `$2B` | 2,540 | [BIN](data/audio/resource_2B.bin) | [WAV](data/audio/resource_2B.wav) | Upgrade not permitted (insufficient cash) | Project owner (listening) |
| `$2C` | 1,628 | [BIN](data/audio/resource_2C.bin) | [WAV](data/audio/resource_2C.wav) | “Red” (spoken in-race) | Project owner (listening) |
| `$2D` | 1,448 | [BIN](data/audio/resource_2D.bin) | [WAV](data/audio/resource_2D.wav) | “White” (spoken in-race) | Project owner (listening) |
| `$2E` | 2,348 | [BIN](data/audio/resource_2E.bin) | [WAV](data/audio/resource_2E.wav) | “Blue” (spoken in-race) | Project owner (listening) |
| `$2F` | 1,352 | [BIN](data/audio/resource_2F.bin) | [WAV](data/audio/resource_2F.wav) | “Pit” (spoken in-race) | Project owner (listening) |
| `$30` | 832 | [BIN](data/audio/resource_30.bin) | [WAV](data/audio/resource_30.wav) / [alternative period](data/audio/resource_30_alt_period_1600.wav) | Collision / bump effect (exact contact type TBC) | Two original-code collision/motion call sites; exact contact event TBC |
| `$31` | 6,398 | [BIN](data/audio/resource_31.bin) | [WAV](data/audio/resource_31.wav) | Injured pit crew | Project owner (listening) |
| `$32` | 13,648 | [BIN](data/audio/resource_32.bin) | [WAV](data/audio/resource_32.wav) | Large collision | Project owner (listening) |
| `$33` | 5,646 | [BIN](data/audio/resource_33.bin) | [WAV](data/audio/resource_33.wav) | Pit service | Project owner (listening) |
| `$34` | 7,658 | [BIN](data/audio/resource_34.bin) | [WAV](data/audio/resource_34.wav) | Pit service complete | Project owner (listening) |
| `$35` | 1,552 | [BIN](data/audio/resource_35.bin) | [WAV](data/audio/resource_35.wav) | Turbo used | Project owner (listening) |
| `$36` | 974 | [BIN](data/audio/resource_36.bin) | [WAV](data/audio/resource_36.wav) | Race-start gun (code-supported; TBC in-game) | Original flag/start sequence at `$B148` / `$B172`; in-game confirmation TBC |
| `$37` | 832 | [BIN](data/audio/resource_37.bin) | [WAV](data/audio/resource_37.wav) | Engine sound (code-supported; TBC in-game) | Original runtime audio/vehicle update at `$D022`; in-game confirmation TBC |


## Raw files and translated audio

The table above supplies **separate direct links** to the original extracted bytes and their translated WAV playback previews. All paths are relative to the Wiki, not the main GitHub repository. In addition, [[Original Disk.1 Resource Schedule]] provides the master resource-by-resource inventory and original non-audio data links.

The WAV conversions are reproducible using the included `wiki/data/Generate-Wiki-Assets.html` (run the [browser-based Wiki asset exporter](data/Generate-Wiki-Assets.html) from the project checkout). Existing `.bin` files are not modified. For each resource it converts Amiga **signed 8-bit PCM** samples to standard WAV **unsigned 8-bit mono PCM**, with a nominal playback preview rate:

```text
WAV playback Hz ≈ 3,546,895 / original descriptor period
```

This is a *nominal PAL Paula-clock calculation* from the descriptor word, **not** a statement that the game always plays the sample at an invariant sample rate. Actual runtime engine pitch, retriggering and loop state may change playback, especially `$37`. `$30` has two period variants and therefore an additional alternative WAV link. WAV files must not replace original raw sample data or be treated as new extracted resources. The ChipTracker modules `$01/$51` remain original binary music files; no falsely labelled musical WAV files are provided without replay/mixing through a verified ChipTracker player.

## Original sound descriptor table and targeted code evidence

The original program’s runtime `$D0CC..$D149` region contains **21 six-byte sound descriptors**. Each descriptor includes an initially zero word, a word referencing the applicable resource-directory entry, and a word used as a playback parameter. **The parameter word is not a PCM sample rate in Hz.** The directory-reference word resolves the actual original resource ID; sound descriptor order must not be assumed to match numerical resource order (the spoken-colour samples are reordered).

| Resource | Descriptor runtime address | Playback parameter | Original call-site reference |
|---|---|---|---|
| `$30` | `$D11A` | `$0898` (2,200) | `$AC08` |
| `$30` | `$D120` | `$0640` (1,600) | `$AE02` |
| `$36` | `$D13E` | `$02A8` (680) | `$B148`, `$B172` |
| `$37` | `$D144` | `$0154` (340) | `$D022` |

These addresses are in the original game’s **runtime address space** (main image loads at `$1000`); subtract `$1000` for offsets into the decompressed main executable. The source bytes were checked against the original `whdload/data/Disk.1` with the existing `app/indyheat.js` decompressor. The following is a concise transcription of the actual sound-descriptor selection instructions (not a speculative pseudocode mapping):

```asm
; Collision/motion code — two playback variants of the same $30 sample:
$AC08: LEA     $D11A(PC),A0    ; $30 descriptor, parameter $0898
$AC0C: BSR.W   $AC5C
$AE02: LEA     $D120(PC),A0    ; $30 descriptor, parameter $0640
$AE06: BSR.W   $AC5C

; Race-start / starting-flag presentation path:
$B148: LEA     $D13E(PC),A0    ; $36 descriptor
$B172: LEA     $D13E(PC),A0    ; same $36 descriptor

; Vehicle-sensitive audio update path:
$D022: LEA     $D144(PC),A0    ; $37 descriptor
$D026: BSR.W   $D08C
```

**Interpretation and boundaries:**

- **`$30` — collision/bump, code-supported but not fully classified.** Both `$AC08` and `$AE02` are in car/contact-motion response code; they choose different playback parameters for the *same* raw sample. The exact distinctions between car-to-car, wall/obstacle and severity still need a bounded branch/consumer trace. It is premature to declare `$30` exclusively car-to-car.
- **`$36` — starting gun, strong code association.** Both references occur in the `$B100..$B1A4` race-start/flag presentation control path; this corroborates the owner’s tentative listening identification. Keep detailed timing of the audible report versus visible gun animation open pending in-game validation.
- **`$37` — engine sound, strong code association.** Selected by the runtime audio update around `$CFD8..$D036`, where vehicle-related state influences sound behaviour. This supports the engine-sound interpretation without proving the exact pitch/speed function, looping or PCM playback rate.

No other sample identity needs fresh audio-format analysis. Resource `$31` is the project owner’s **injured pit crew** sound; `$32` is the separate **large collision** sound and should not be conflated with the two `$30` contact variants.

## Evidence and continued work

- Original source is `whdload/data/Disk.1`; resource IDs come from the original `$4C6A` directory (main offset `$3C6A`). The established retail loader/decompression contract is on [[Disk Image, Loader and Runtime Resource Map]].
- **Settled:** two ChipTracker music files; twenty extracted raw signed 8-bit 8SVX-style sample bodies; 17 owner-confirmed effect identities; original sound-descriptor table and four targeted sound selector locations. Do not reopen location, format or owner-confirmed audible identities as a prerequisite to unrelated work.
- **Bounded open questions:** precise `$30` contact-condition split; `$36` visual/audio timing (if required); `$37` pitch/loop update mechanism and original playback-rate parameter interpretation.
- A future sample-contact/audio reference should preserve original bytes, sample-rate evidence, and loop/retrigger interpretation rather than applying destructive audio filters.
