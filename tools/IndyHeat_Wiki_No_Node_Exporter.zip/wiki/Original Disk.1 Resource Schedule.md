# Original Disk.1 Resource Schedule

Updated: 8 October 2026 (presentation graphics and file links). This is the **single index** for the original game's resource-directory entries. It includes unidentified entries explicitly instead of silently treating them as code. Details, rendered/viewable files and the original extracted data are now separate table columns. This prevents links to the resource’s description being confused with links to an actual rendered asset.

## Source and counting rule

- Original source: [`whdload/data/Disk.1`](https://github.com/HoraceAndTheSpider/Indy-Heat-WHD/raw/refs/heads/master/whdload/data/Disk.1), **901,120 bytes**, Git blob SHA `8422415c1a60195b5e82edb43731f01ba1262aa6` when inventoried on 8 October 2026.
- Packed main program: sector **22** (`$2C00`), Imploder output `$1206A` bytes, loaded at runtime `$1000`. The resource-directory table begins at main image `+$3C6A` / runtime `$4C6A`. Each directory record is **22 bytes** and its sector/size values are big-endian.
- **Valid physical resource IDs:** `$00..$6A` = **107 entries**. One further sequential-looking 22-byte slot starts with ID `$006B` but has an impossible sector number **13,308** and decompressed size **14,676,122** (far outside a 1,760-sector disk); it is **not accepted as a disk resource**. An older statement that the resource directory contained 108 usable entries counted this malformed slot. Do not use it as a file or make a false graphical classification.
- The catalogue includes every physically indexed record, whether currently understood or unknown. Items not present in this schedule are original executable/code, incidental buffers/embedded tables or non-directory bytes—not *additional* indexed resources. **Unknown listed items must not be called code merely because their role has not been decoded.**
- The schedule is derived from the current checked-in `app/indyheat.js` File Imploder decruncher and resource table parser plus the byte-exact GitHub `Disk.1`. It does not rely on earlier rendered Dropbox images.
- `Unpacked bytes` are directory values; even where the decoder recognises File Imploder payloads, this table is an index rather than a claim that every stream has the same compression/wrapper (`KLUD` audio differs).

### Asset files and reproducibility

All file links are **relative to this Wiki** and use the `wiki/data/` tree:

- `data/audio/` — existing moved **ChipTracker music and raw sample BINs**, with converted WAVs generated alongside (original BIN files are retained).
- `data/raw/` — *losslessly unpacked* original resource payloads; the exception `$1C` is labelled `_packed.bin` because its compression/wrapper is not yet decoded, so its original occupied sectors are preserved without claiming decompression.
- `data/graphics/` — PNG views of identified bitmap resources, rendered object-bank contact sheets and individual `$12` frames. Screen images represent original source pixels but **their display palette may require game-mode-specific refinement**. Raw bytes are the unmodified authority.
- `data/Generate-Wiki-Assets.html` — browser-based offline producer for these graphics, uncompressed source blocks and WAVs. Open [Generate-Wiki-Assets.html](data/Generate-Wiki-Assets.html) from your local `wiki/data/` folder; select `Disk.1` and the existing extracted audio BINs, then click **Generate ZIP**. It uses current `app/indyheat.js` and `app/indyheat_race_graphics.js` and needs no installation. A link will resolve only once the corresponding file has been generated and copied/pushed into the Wiki. The source data and this index may therefore be committed separately from the heavier generated assets.

The `data/graphics/resource_XX.png` files are inspection views; the source-clean original is the `.bin` column. WAVs are non-destructive conversions of already-extracted signed eight-bit PCM. See [[Audio Resources and Formats]] for sample-rate/period caveats.


## All resource-directory entries

| ID | First sector | Sectors | Unpacked bytes | Identity / content | Confidence / notes | Wiki details | Viewable file | Original data |
|---|---:|---:|---:|---|---|---|---|---|
| `$00` | 151 | 1 | 310 | Unknown payload (do not assume code) | Unclassified | — | — | [BIN](data/raw/resource_00.bin) |
| `$01` | 152 | 329 | 182,004 | ChipTracker music – BIGRUN | Format confirmed | [[Audio Resources and Formats]] | — | [ChipTracker BIN](data/audio/resource_01_BIGRUN.bin) |
| `$02` | 481 | 32 | 51,200 | Indy Heat title screen / opening illustration | Decoded 320×256, 5-plane image | [[Presentation and Graphics Resource Files]] | [PNG](data/graphics/resource_02.png) | [BIN](data/raw/resource_02.bin) |
| `$03` | 513 | 6 | 51,200 | Side-on racing-car presentation artwork | Decoded 320×256, 5-plane image | [[Presentation and Graphics Resource Files]] | [PNG](data/graphics/resource_03.png) | [BIN](data/raw/resource_03.bin) |
| `$04` | 519 | 27 | 51,200 | Gasoline Alley/shop backdrop with car-colour display panels | Decoded 320×256, 5-plane image | [[Presentation and Graphics Resource Files]] | [PNG](data/graphics/resource_04.png) | [BIN](data/raw/resource_04.bin) |
| `$05` | 546 | 46 | 47,584 | Pit crew (304 frames) | Established | [[Race Presentation and Graphics Resources]] | [Frame sheet PNG](data/graphics/resource_05_contact.png) | [BIN](data/raw/resource_05.bin) |
| `$06` | 592 | 2 | 2,288 | Car damage/debris (64) | Established | [[Race Presentation and Graphics Resources]] | [Frame sheet PNG](data/graphics/resource_06_contact.png) | [BIN](data/raw/resource_06.bin) |
| `$07` | 594 | 1 | 596 | Damaged-car smoke (11) | Established | [[Race Presentation and Graphics Resources]] | [Frame sheet PNG](data/graphics/resource_07_contact.png) | [BIN](data/raw/resource_07.bin) |
| `$08` | 595 | 4 | 5,984 | PIT-board attendants (64) | Established | [[Race Presentation and Graphics Resources]] | [Frame sheet PNG](data/graphics/resource_08_contact.png) | [BIN](data/raw/resource_08.bin) |
| `$09` | 599 | 2 | 2,064 | Grass/gravel tyre spray (56) | Established | [[Race Presentation and Graphics Resources]] | [Frame sheet PNG](data/graphics/resource_09_contact.png) | [BIN](data/raw/resource_09.bin) |
| `$0A` | 601 | 3 | 2,148 | Fire overlay (33) | Established | [[Race Presentation and Graphics Resources]] | [Frame sheet PNG](data/graphics/resource_0A_contact.png) | [BIN](data/raw/resource_0A.bin) |
| `$0B` | 604 | 4 | 3,144 | Out-of-fuel overlay (26) | Established | [[Race Presentation and Graphics Resources]] | [Frame sheet PNG](data/graphics/resource_0B_contact.png) | [BIN](data/raw/resource_0B.bin) |
| `$0C` | 608 | 2 | 1,292 | Out-of-fuel smoke/effect (25) | Established | [[Race Presentation and Graphics Resources]] | [Frame sheet PNG](data/graphics/resource_0C_contact.png) | [BIN](data/raw/resource_0C.bin) |
| `$0D` | 610 | 2 | 5,304 | Speedometer (17) | Established | [[Race Presentation and Graphics Resources]] | [Frame sheet PNG](data/graphics/resource_0D_contact.png) | [BIN](data/raw/resource_0D.bin) |
| `$0E` | 612 | 2 | 2,312 | PIT notice boards/HUD refresh (6) | Established | [[Race Presentation and Graphics Resources]] | [Frame sheet PNG](data/graphics/resource_0E_contact.png) | [BIN](data/raw/resource_0E.bin) |
| `$0F` | 614 | 3 | 2,704 | Flag man/starting gun (36) | Established | [[Race Presentation and Graphics Resources]] | [Frame sheet PNG](data/graphics/resource_0F_contact.png) | [BIN](data/raw/resource_0F.bin) |
| `$10` | 617 | 15 | 10,518 | Driver faces A (44) | Established | [[Race Presentation and Graphics Resources]] | [Frame sheet PNG](data/graphics/resource_10_contact.png) | [BIN](data/raw/resource_10.bin) |
| `$11` | 632 | 15 | 10,518 | Driver faces B (44) | Established | [[Race Presentation and Graphics Resources]] | [Frame sheet PNG](data/graphics/resource_11_contact.png) | [BIN](data/raw/resource_11.bin) |
| `$12` | 647 | 32 | 51,008 | Gasoline Alley graphics and UI BOB bank — 29 frames | Strict original five-plane BOB decoding; full 29-frame contact sheet | [[Presentation and Graphics Resource Files]] | [29-frame PNG sheet](data/graphics/resource_12_contact.png) | [BIN](data/raw/resource_12.bin) |
| `$13` | 679 | 1 | 766 | Unknown payload (do not assume code) | Unclassified | — | — | [BIN](data/raw/resource_13.bin) |
| `$14` | 680 | 1 | 766 | Unknown payload (do not assume code) | Unclassified | — | — | [BIN](data/raw/resource_14.bin) |
| `$15` | 681 | 3 | 4,246 | Unknown payload (do not assume code) | Unclassified | — | — | [BIN](data/raw/resource_15.bin) |
| `$16` | 684 | 10 | 8,374 | Regional/North USA map graphics and marker display data | Established | [[Track Data and Runtime Setup#Regional maps]] | — | [BIN](data/raw/resource_16.bin) |
| `$17` | 694 | 2 | 868 | Unknown payload (do not assume code) | Unclassified | — | — | [BIN](data/raw/resource_17.bin) |
| `$18` | 696 | 4 | 2,562 | West Canada circuit MiniMap / preview; one 78×51 five-plane BOB | Established | [[Race, Car and Pit Runtime Structures#Miniature circuit preview and regional-map marker]] | [MiniMap PNG](data/graphics/resource_18.png) | [BIN](data/raw/resource_18.bin) |
| `$19` | 700 | 4 | 2,562 | South California circuit MiniMap / preview; one 78×51 five-plane BOB | Established | [[Race, Car and Pit Runtime Structures#Miniature circuit preview and regional-map marker]] | [MiniMap PNG](data/graphics/resource_19.png) | [BIN](data/raw/resource_19.bin) |
| `$1A` | 704 | 4 | 2,562 | Michigan circuit MiniMap / preview; one 78×51 five-plane BOB | Established | [[Race, Car and Pit Runtime Structures#Miniature circuit preview and regional-map marker]] | [MiniMap PNG](data/graphics/resource_1A.png) | [BIN](data/raw/resource_1A.bin) |
| `$1B` | 708 | 4 | 2,562 | Illinois circuit MiniMap / preview; one 78×51 five-plane BOB | Established | [[Race, Car and Pit Runtime Structures#Miniature circuit preview and regional-map marker]] | [MiniMap PNG](data/graphics/resource_1B.png) | [BIN](data/raw/resource_1B.bin) |
| `$1C` | 712 | 1 | 70 | Unknown payload (do not assume code) | Unclassified | — | — | [Packed sectors](data/raw/resource_1C_packed.bin) |
| `$1D` | 713 | 4 | 2,562 | New Jersey circuit MiniMap / preview; one 78×51 five-plane BOB | Established | [[Race, Car and Pit Runtime Structures#Miniature circuit preview and regional-map marker]] | [MiniMap PNG](data/graphics/resource_1D.png) | [BIN](data/raw/resource_1D.bin) |
| `$1E` | 717 | 4 | 2,562 | East Canada circuit MiniMap / preview; one 78×51 five-plane BOB | Established | [[Race, Car and Pit Runtime Structures#Miniature circuit preview and regional-map marker]] | [MiniMap PNG](data/graphics/resource_1E.png) | [BIN](data/raw/resource_1E.bin) |
| `$1F` | 721 | 4 | 2,562 | Kentucky circuit MiniMap / preview; one 78×51 five-plane BOB | Established | [[Race, Car and Pit Runtime Structures#Miniature circuit preview and regional-map marker]] | [MiniMap PNG](data/graphics/resource_1F.png) | [BIN](data/raw/resource_1F.bin) |
| `$20` | 725 | 5 | 2,562 | North California circuit MiniMap / preview; one 78×51 five-plane BOB | Established | [[Race, Car and Pit Runtime Structures#Miniature circuit preview and regional-map marker]] | [MiniMap PNG](data/graphics/resource_20.png) | [BIN](data/raw/resource_20.bin) |
| `$21` | 730 | 4 | 2,562 | Colorado circuit MiniMap / preview; one 78×51 five-plane BOB | Established | [[Race, Car and Pit Runtime Structures#Miniature circuit preview and regional-map marker]] | [MiniMap PNG](data/graphics/resource_21.png) | [BIN](data/raw/resource_21.bin) |
| `$22` | 734 | 4 | 2,562 | Indianapolis circuit MiniMap / preview; one 78×51 five-plane BOB | Established | [[Race, Car and Pit Runtime Structures#Miniature circuit preview and regional-map marker]] | [MiniMap PNG](data/graphics/resource_22.png) | [BIN](data/raw/resource_22.bin) |
| `$23` | 738 | 1 | 5,932 | Unknown payload (do not assume code) | Unclassified | — | — | [BIN](data/raw/resource_23.bin) |
| `$24` | 739 | 5 | 2,216 | Turbo Upgrade | Owner-confirmed audible identity | [[Audio Resources and Formats]] | [WAV](data/audio/resource_24.wav) | [PCM BIN](data/audio/resource_24.bin) |
| `$25` | 744 | 3 | 1,412 | Brake Upgrade | Owner-confirmed audible identity | [[Audio Resources and Formats]] | [WAV](data/audio/resource_25.wav) | [PCM BIN](data/audio/resource_25.bin) |
| `$26` | 747 | 14 | 7,040 | Tyres Upgrade | Owner-confirmed audible identity | [[Audio Resources and Formats]] | [WAV](data/audio/resource_26.wav) | [PCM BIN](data/audio/resource_26.bin) |
| `$27` | 761 | 7 | 3,650 | Crew Upgrade | Owner-confirmed audible identity | [[Audio Resources and Formats]] | [WAV](data/audio/resource_27.wav) | [PCM BIN](data/audio/resource_27.bin) |
| `$28` | 768 | 8 | 3,678 | MPG Upgrade | Owner-confirmed audible identity | [[Audio Resources and Formats]] | [WAV](data/audio/resource_28.wav) | [PCM BIN](data/audio/resource_28.bin) |
| `$29` | 776 | 12 | 6,050 | Engine Upgrade | Owner-confirmed audible identity | [[Audio Resources and Formats]] | [WAV](data/audio/resource_29.wav) | [PCM BIN](data/audio/resource_29.bin) |
| `$2A` | 788 | 2 | 676 | Start Next Race clicked | Owner-confirmed audible identity | [[Audio Resources and Formats]] | [WAV](data/audio/resource_2A.wav) | [PCM BIN](data/audio/resource_2A.bin) |
| `$2B` | 790 | 5 | 2,540 | Upgrade not permitted (insufficient cash) | Owner-confirmed audible identity | [[Audio Resources and Formats]] | [WAV](data/audio/resource_2B.wav) | [PCM BIN](data/audio/resource_2B.bin) |
| `$2C` | 795 | 4 | 1,628 | “Red” (spoken in-race) | Owner-confirmed audible identity | [[Audio Resources and Formats]] | [WAV](data/audio/resource_2C.wav) | [PCM BIN](data/audio/resource_2C.bin) |
| `$2D` | 799 | 3 | 1,448 | “White” (spoken in-race) | Owner-confirmed audible identity | [[Audio Resources and Formats]] | [WAV](data/audio/resource_2D.wav) | [PCM BIN](data/audio/resource_2D.bin) |
| `$2E` | 802 | 5 | 2,348 | “Blue” (spoken in-race) | Owner-confirmed audible identity | [[Audio Resources and Formats]] | [WAV](data/audio/resource_2E.wav) | [PCM BIN](data/audio/resource_2E.bin) |
| `$2F` | 807 | 3 | 1,352 | “Pit” (spoken in-race) | Owner-confirmed audible identity | [[Audio Resources and Formats]] | [WAV](data/audio/resource_2F.wav) | [PCM BIN](data/audio/resource_2F.bin) |
| `$30` | 810 | 2 | 832 | Audio sample — Collision / bump effect (exact contact type TBC) | Code association; exact interpretation TBC | [[Audio Resources and Formats]] | [WAV](data/audio/resource_30.wav) | [PCM BIN](data/audio/resource_30.bin) |
| `$31` | 812 | 13 | 6,398 | Injured pit crew | Owner-confirmed audible identity | [[Audio Resources and Formats]] | [WAV](data/audio/resource_31.wav) | [PCM BIN](data/audio/resource_31.bin) |
| `$32` | 825 | 26 | 13,648 | Large collision | Owner-confirmed audible identity | [[Audio Resources and Formats]] | [WAV](data/audio/resource_32.wav) | [PCM BIN](data/audio/resource_32.bin) |
| `$33` | 851 | 11 | 5,646 | Pit service | Owner-confirmed audible identity | [[Audio Resources and Formats]] | [WAV](data/audio/resource_33.wav) | [PCM BIN](data/audio/resource_33.bin) |
| `$34` | 862 | 14 | 7,658 | Pit service complete | Owner-confirmed audible identity | [[Audio Resources and Formats]] | [WAV](data/audio/resource_34.wav) | [PCM BIN](data/audio/resource_34.bin) |
| `$35` | 876 | 4 | 1,552 | Turbo used | Owner-confirmed audible identity | [[Audio Resources and Formats]] | [WAV](data/audio/resource_35.wav) | [PCM BIN](data/audio/resource_35.bin) |
| `$36` | 880 | 2 | 974 | Audio sample — Race-start gun (code-supported; TBC in-game) | Code association; exact interpretation TBC | [[Audio Resources and Formats]] | [WAV](data/audio/resource_36.wav) | [PCM BIN](data/audio/resource_36.bin) |
| `$37` | 882 | 2 | 832 | Audio sample — Engine sound (code-supported; TBC in-game) | Code association; exact interpretation TBC | [[Audio Resources and Formats]] | [WAV](data/audio/resource_37.wav) | [PCM BIN](data/audio/resource_37.bin) |
| `$38` | 884 | 18 | 12,968 | Racing cars (336) | Established | [[Race Presentation and Graphics Resources]] | [Frame sheet PNG](data/graphics/resource_38_contact.png) | [BIN](data/raw/resource_38.bin) |
| `$39` | 902 | 56 | 51,200 | Illinois – Backdrop graphic (320×256 × 5 planes) | Established | [[Track Data and Runtime Setup]] | [Backdrop PNG](data/graphics/resource_39.png) | [BIN](data/raw/resource_39.bin) |
| `$3A` | 958 | 3 | 10,244 | Illinois – Foreground/occlusion (1bpp) | Established | [[Track Data and Runtime Setup]] | [Map PNG](data/graphics/resource_3A.png) | [BIN](data/raw/resource_3A.bin) |
| `$3B` | 961 | 2 | 4,480 | Illinois – Surface/collision map (160×112, 2bpp) | Established | [[Track Data and Runtime Setup]] | [Map PNG](data/graphics/resource_3B.png) | [BIN](data/raw/resource_3B.bin) |
| `$3C` | 963 | 1 | 1,120 | Illinois – Recovery direction grid (40×28 bytes) | Established | [[Track Data and Runtime Setup]] | [Map PNG](data/graphics/resource_3C.png) | [BIN](data/raw/resource_3C.bin) |
| `$3D` | 964 | 63 | 51,200 | New Jersey – Backdrop graphic (320×256 × 5 planes) | Established | [[Track Data and Runtime Setup]] | [Backdrop PNG](data/graphics/resource_3D.png) | [BIN](data/raw/resource_3D.bin) |
| `$3E` | 1,027 | 4 | 10,240 | New Jersey – Foreground/occlusion (1bpp) | Established | [[Track Data and Runtime Setup]] | [Map PNG](data/graphics/resource_3E.png) | [BIN](data/raw/resource_3E.bin) |
| `$3F` | 1,031 | 3 | 4,480 | New Jersey – Surface/collision map (160×112, 2bpp) | Established | [[Track Data and Runtime Setup]] | [Map PNG](data/graphics/resource_3F.png) | [BIN](data/raw/resource_3F.bin) |
| `$40` | 1,034 | 1 | 1,120 | New Jersey – Recovery direction grid (40×28 bytes) | Established | [[Track Data and Runtime Setup]] | [Map PNG](data/graphics/resource_40.png) | [BIN](data/raw/resource_40.bin) |
| `$41` | 1,035 | 63 | 51,200 | West Canada – Backdrop graphic (320×256 × 5 planes) | Established | [[Track Data and Runtime Setup]] | [Backdrop PNG](data/graphics/resource_41.png) | [BIN](data/raw/resource_41.bin) |
| `$42` | 1,098 | 5 | 10,244 | West Canada – Foreground/occlusion (1bpp) | Established | [[Track Data and Runtime Setup]] | [Map PNG](data/graphics/resource_42.png) | [BIN](data/raw/resource_42.bin) |
| `$43` | 1,103 | 3 | 4,480 | West Canada – Surface/collision map (160×112, 2bpp) | Established | [[Track Data and Runtime Setup]] | [Map PNG](data/graphics/resource_43.png) | [BIN](data/raw/resource_43.bin) |
| `$44` | 1,106 | 1 | 1,120 | West Canada – Recovery direction grid (40×28 bytes) | Established | [[Track Data and Runtime Setup]] | [Map PNG](data/graphics/resource_44.png) | [BIN](data/raw/resource_44.bin) |
| `$45` | 1,107 | 63 | 51,200 | South California – Backdrop graphic (320×256 × 5 planes) | Established | [[Track Data and Runtime Setup]] | [Backdrop PNG](data/graphics/resource_45.png) | [BIN](data/raw/resource_45.bin) |
| `$46` | 1,170 | 6 | 10,244 | South California – Foreground/occlusion (1bpp) | Established | [[Track Data and Runtime Setup]] | [Map PNG](data/graphics/resource_46.png) | [BIN](data/raw/resource_46.bin) |
| `$47` | 1,176 | 3 | 4,480 | South California – Surface/collision map (160×112, 2bpp) | Established | [[Track Data and Runtime Setup]] | [Map PNG](data/graphics/resource_47.png) | [BIN](data/raw/resource_47.bin) |
| `$48` | 1,179 | 1 | 1,120 | South California – Recovery direction grid (40×28 bytes) | Established | [[Track Data and Runtime Setup]] | [Map PNG](data/graphics/resource_48.png) | [BIN](data/raw/resource_48.bin) |
| `$49` | 1,180 | 57 | 51,200 | East Canada – Backdrop graphic (320×256 × 5 planes) | Established | [[Track Data and Runtime Setup]] | [Backdrop PNG](data/graphics/resource_49.png) | [BIN](data/raw/resource_49.bin) |
| `$4A` | 1,237 | 5 | 10,240 | East Canada – Foreground/occlusion (1bpp) | Established | [[Track Data and Runtime Setup]] | [Map PNG](data/graphics/resource_4A.png) | [BIN](data/raw/resource_4A.bin) |
| `$4B` | 1,242 | 2 | 4,480 | East Canada – Surface/collision map (160×112, 2bpp) | Established | [[Track Data and Runtime Setup]] | [Map PNG](data/graphics/resource_4B.png) | [BIN](data/raw/resource_4B.bin) |
| `$4C` | 1,244 | 1 | 1,120 | East Canada – Recovery direction grid (40×28 bytes) | Established | [[Track Data and Runtime Setup]] | [Map PNG](data/graphics/resource_4C.png) | [BIN](data/raw/resource_4C.bin) |
| `$4D` | 1,245 | 53 | 51,200 | Indianapolis – Backdrop graphic (320×256 × 5 planes) | Established | [[Track Data and Runtime Setup]] | [Backdrop PNG](data/graphics/resource_4D.png) | [BIN](data/raw/resource_4D.bin) |
| `$4E` | 1,298 | 2 | 10,240 | Indianapolis – Foreground/occlusion (1bpp) | Established | [[Track Data and Runtime Setup]] | [Map PNG](data/graphics/resource_4E.png) | [BIN](data/raw/resource_4E.bin) |
| `$4F` | 1,300 | 2 | 4,480 | Indianapolis – Surface/collision map (160×112, 2bpp) | Established | [[Track Data and Runtime Setup]] | [Map PNG](data/graphics/resource_4F.png) | [BIN](data/raw/resource_4F.bin) |
| `$50` | 1,302 | 1 | 1,120 | Indianapolis – Recovery direction grid (40×28 bytes) | Established | [[Track Data and Runtime Setup]] | [Map PNG](data/graphics/resource_50.png) | [BIN](data/raw/resource_50.bin) |
| `$51` | 1,303 | 45 | 26,308 | ChipTracker music – BIGRUNHISCORE | Format confirmed | [[Audio Resources and Formats]] | — | [ChipTracker BIN](data/audio/resource_51_BIGRUNHISCORE.bin) |
| `$52` | 1,348 | 23 | 51,200 | Championship results/podium presentation backdrop | Decoded 320×256, 5-plane image | [[Presentation and Graphics Resource Files]] | [PNG](data/graphics/resource_52.png) | [BIN](data/raw/resource_52.bin) |
| `$53` | 1,371 | 8 | 6,470 | Unknown payload (do not assume code) | Unclassified | — | — | [BIN](data/raw/resource_53.bin) |
| `$54` | 1,379 | 6 | 7,812 | Unknown payload (do not assume code) | Unclassified | — | — | [BIN](data/raw/resource_54.bin) |
| `$55` | 1,385 | 6 | 7,812 | Unknown payload (do not assume code) | Unclassified | — | — | [BIN](data/raw/resource_55.bin) |
| `$56` | 1,391 | 18 | 51,200 | Current Leaders/results presentation backdrop | Decoded 320×256, 5-plane image | [[Presentation and Graphics Resource Files]] | [PNG](data/graphics/resource_56.png) | [BIN](data/raw/resource_56.bin) |
| `$57` | 1,409 | 8 | 14,184 | Unknown payload (do not assume code) | Unclassified | — | — | [BIN](data/raw/resource_57.bin) |
| `$58` | 1,417 | 6 | 51,200 | Hall of Fame/high-score presentation backdrop | Decoded 320×256, 5-plane image | [[Presentation and Graphics Resource Files]] | [PNG](data/graphics/resource_58.png) | [BIN](data/raw/resource_58.bin) |
| `$59` | 1,423 | 3 | 12,526 | Unknown payload (do not assume code) | Unclassified | — | — | [BIN](data/raw/resource_59.bin) |
| `$5A` | 1,426 | 51 | 51,200 | Michigan – Backdrop graphic (320×256 × 5 planes) | Established | [[Track Data and Runtime Setup]] | [Backdrop PNG](data/graphics/resource_5A.png) | [BIN](data/raw/resource_5A.bin) |
| `$5B` | 1,477 | 4 | 10,244 | Michigan – Foreground/occlusion (1bpp) | Established | [[Track Data and Runtime Setup]] | [Map PNG](data/graphics/resource_5B.png) | [BIN](data/raw/resource_5B.bin) |
| `$5C` | 1,481 | 2 | 4,480 | Michigan – Surface/collision map (160×112, 2bpp) | Established | [[Track Data and Runtime Setup]] | [Map PNG](data/graphics/resource_5C.png) | [BIN](data/raw/resource_5C.bin) |
| `$5D` | 1,483 | 1 | 1,120 | Michigan – Recovery direction grid (40×28 bytes) | Established | [[Track Data and Runtime Setup]] | [Map PNG](data/graphics/resource_5D.png) | [BIN](data/raw/resource_5D.bin) |
| `$5E` | 1,484 | 55 | 51,200 | Colorado – Backdrop graphic (320×256 × 5 planes) | Established | [[Track Data and Runtime Setup]] | [Backdrop PNG](data/graphics/resource_5E.png) | [BIN](data/raw/resource_5E.bin) |
| `$5F` | 1,539 | 3 | 10,240 | Colorado – Foreground/occlusion (1bpp) | Established | [[Track Data and Runtime Setup]] | [Map PNG](data/graphics/resource_5F.png) | [BIN](data/raw/resource_5F.bin) |
| `$60` | 1,542 | 2 | 4,480 | Colorado – Surface/collision map (160×112, 2bpp) | Established | [[Track Data and Runtime Setup]] | [Map PNG](data/graphics/resource_60.png) | [BIN](data/raw/resource_60.bin) |
| `$61` | 1,544 | 1 | 1,120 | Colorado – Recovery direction grid (40×28 bytes) | Established | [[Track Data and Runtime Setup]] | [Map PNG](data/graphics/resource_61.png) | [BIN](data/raw/resource_61.bin) |
| `$62` | 1,545 | 68 | 51,200 | North California – Backdrop graphic (320×256 × 5 planes) | Established | [[Track Data and Runtime Setup]] | [Backdrop PNG](data/graphics/resource_62.png) | [BIN](data/raw/resource_62.bin) |
| `$63` | 1,613 | 5 | 10,240 | North California – Foreground/occlusion (1bpp) | Established | [[Track Data and Runtime Setup]] | [Map PNG](data/graphics/resource_63.png) | [BIN](data/raw/resource_63.bin) |
| `$64` | 1,618 | 3 | 4,480 | North California – Surface/collision map (160×112, 2bpp) | Established | [[Track Data and Runtime Setup]] | [Map PNG](data/graphics/resource_64.png) | [BIN](data/raw/resource_64.bin) |
| `$65` | 1,621 | 1 | 1,120 | North California – Recovery direction grid (40×28 bytes) | Established | [[Track Data and Runtime Setup]] | [Map PNG](data/graphics/resource_65.png) | [BIN](data/raw/resource_65.bin) |
| `$66` | 1,622 | 67 | 51,200 | Kentucky – Backdrop graphic (320×256 × 5 planes) | Established | [[Track Data and Runtime Setup]] | [Backdrop PNG](data/graphics/resource_66.png) | [BIN](data/raw/resource_66.bin) |
| `$67` | 1,689 | 5 | 10,240 | Kentucky – Foreground/occlusion (1bpp) | Established | [[Track Data and Runtime Setup]] | [Map PNG](data/graphics/resource_67.png) | [BIN](data/raw/resource_67.bin) |
| `$68` | 1,694 | 4 | 4,480 | Kentucky – Surface/collision map (160×112, 2bpp) | Established | [[Track Data and Runtime Setup]] | [Map PNG](data/graphics/resource_68.png) | [BIN](data/raw/resource_68.bin) |
| `$69` | 1,698 | 1 | 1,120 | Kentucky – Recovery direction grid (40×28 bytes) | Established | [[Track Data and Runtime Setup]] | [Map PNG](data/graphics/resource_69.png) | [BIN](data/raw/resource_69.bin) |
| `$6A` | 1,699 | 5 | 2,312 | Unknown payload (do not assume code) | Unclassified | — | — | [BIN](data/raw/resource_6A.bin) |

## Graphical resource accounting

Currently decoded object-frame banks include `$05–$11` (13 banks), `$12` (29 Gasoline Alley frames) and `$38` (cars). Together they contain **1,095 frames across 15 banks** (the pre-existing race decoder covered 1,066; `$12` adds 29). The ten `$0A02`-byte retail circuit previews are additional, separate single-frame graphics; physical track Backdrops and Foreground masks are also graphics rather than object-frame banks. The previously unclassified large presentation resources `$02/$03/$04/$52/$56/$58` are now identified visually from their original five-plane image data. Resource `$12` is a **29-frame five-plane Gasoline Alley BOB bank**, not a single bitmap. Other smaller unknown resources remain explicitly unknown.

The complete graphical-asset documentation goal is: a source-clean, reproducible decompressed binary; format/size/palette; all numbered frames in a contact sheet; individual transparent PNGs for sprites; and links to the runtime selector and game-code addresses. Images already in `wiki/images/` are **evidence** rather than substitutes for Disk.1 extraction. No artwork is generated or replaced by this index.

## Notes on classifications

- Four resources per retail physical circuit are fixed at ten bases: `$39`, `$3D`, `$41`, `$45`, `$49`, `$4D`, `$5A`, `$5E`, `$62`, `$66` (the game reuses Indianapolis for event 11).
- `$51` is **music**, **not** part of a four-resource track group. `$52`, `$56` and `$58` have been rendered and visually identified as results/leaderboard/high-score presentation backdrops. The intervening `$53/$54/$55/$57/$59` remain separately unclassified; bitmap sizes are not used to assign them meanings.
- The ten circuit-preview resource IDs are `$18`, `$19`, `$1A`, `$1B`, `$1D`, `$1E`, `$1F`, `$20`, `$21`, `$22`. `$1C` is *not* a preview and remains unclassified.
- `$24..$37` are the original **20 audio-sample resources**; 17 identities are owner-confirmed and three have bounded code-supported provisional descriptions on [[Audio Resources and Formats]].
- `$6A` is an additional resource after Kentucky's four-item group; do not assume it is a fifth Kentucky layer.
- The physical first sector is measured in 512-byte sectors; a resource's `readSize` or occupied sectors should not be mistaken for its **unpacked** size.