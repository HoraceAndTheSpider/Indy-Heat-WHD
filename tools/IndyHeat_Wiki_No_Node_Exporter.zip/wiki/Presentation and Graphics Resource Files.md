# Presentation and Graphics Resource Files

Updated: 8 October 2026. This is the direct-file companion to [[Original Disk.1 Resource Schedule]]. It links every decoded large presentation image and the principal original sprite resources. Detailed runtime/format research remains on [[Race Presentation and Graphics Resources]], while circuit-specific formats and links remain on [[Track Data and Runtime Setup]].

**Separation:** The **Wiki details** column links to descriptions and decoding knowledge. The **View/PNG** column opens an image or numbered sprite sheet. **Original/BIN** is the unmodified decompressed source. All links are paths beneath `wiki/data/`. Files are reproducibly generated from the current original Disk.1 using the [browser-based Wiki asset exporter](data/Generate-Wiki-Assets.html); the generator does not alter `Disk.1`, the app, or existing audio BINs.

## Previously unidentified large graphics

All these visual classifications were made by decoding the original `Disk.1`, not by guessing from byte counts or relying on pre-rendered files. The 51,200-byte items decode as full-screen 320×256 five-bitplane artwork. The 51,008-byte `$12` is **not a full-screen bitmap**.

| Resource | Confirmed content | Format | Rendered PNG | Original data |
|---|---|---|---|---|
| `$02` | Indy Heat opening/title screen | 320×256, 5 planes | [PNG](data/graphics/resource_02.png) | [BIN](data/raw/resource_02.bin) |
| `$03` | Side-profile racing car / vehicle presentation | 320×256, 5 planes | [PNG](data/graphics/resource_03.png) | [BIN](data/raw/resource_03.bin) |
| `$04` | Gasoline Alley/shop background with car-colour panels | 320×256, 5 planes | [PNG](data/graphics/resource_04.png) | [BIN](data/raw/resource_04.bin) |
| `$12` | Gasoline Alley upgrade illustrations, explanatory captions and controls — 29 frames | 29 five-plane BOB frames | [PNG](data/graphics/resource_12_contact.png) | [BIN](data/raw/resource_12.bin) |
| `$52` | Race/championship standings and podium presentation | 320×256, 5 planes | [PNG](data/graphics/resource_52.png) | [BIN](data/raw/resource_52.bin) |
| `$56` | Current Leaders display | 320×256, 5 planes | [PNG](data/graphics/resource_56.png) | [BIN](data/raw/resource_56.bin) |
| `$58` | Hall of Fame / high-score backdrop | 320×256, 5 planes | [PNG](data/graphics/resource_58.png) | [BIN](data/raw/resource_58.bin) |

### Resource `$12` — 29-frame Gasoline Alley BOB bank

The unusual `$C740` (**51,008-byte**) decompressed size arises from concatenated, self-describing BOB frames of different dimensions, not from an image with two missing scanlines. The generic twelve-byte header/plane-major decoder already used for race objects parses the bank **strictly to 29 frames** with no leftover bytes.

```text
frame header +00.w width   +02.w height   +04.w X origin
             +06.w Y origin   +08.w transparent SOURCE index
             +0A.w plane count = 5
payload      ceil(width/16)*2 * height * 5 bytes, plane-major
```

The bank contains artwork and controls for the upgrade/shop interface, including an upgrade-picture sequence (frames 1–8), eight caption/description strips (9–16), tiny blank/marker frames (17–20), and larger shop graphics, car display and control panels (21–28). Frame 0 is a small border/box image. This is a **visual classification** based on clean source decoding; consumer addresses and detailed per-frame timing remain separate research if they ever become necessary.

[All 29 frames — contact sheet](data/graphics/resource_12_contact.png) · [Original $C740-byte bank](data/raw/resource_12.bin). Numbered individual files use `data/graphics/resource_12_frame_000.png` through `resource_12_frame_028.png`.

## Race sprite banks

The frame count, binary format, transparent-index rules and original code selectors are documented on [[Race Presentation and Graphics Resources]]. Every link below refers to regenerated PNGs from the original Disk.1 and source-clean unpacked bank bytes.

| Resource | Original content | Numbered PNG frames | Original data |
|---|---|---|---|
| `$05` | Pit crew (304 frames) | [Contact sheet](data/graphics/resource_05_contact.png) | [BIN](data/raw/resource_05.bin) |
| `$06` | Car damage/debris (64 frames) | [Contact sheet](data/graphics/resource_06_contact.png) | [BIN](data/raw/resource_06.bin) |
| `$07` | Damaged-car smoke (11 frames) | [Contact sheet](data/graphics/resource_07_contact.png) | [BIN](data/raw/resource_07.bin) |
| `$08` | Pit board attendants (64 frames) | [Contact sheet](data/graphics/resource_08_contact.png) | [BIN](data/raw/resource_08.bin) |
| `$09` | Grass/gravel spray (56 frames) | [Contact sheet](data/graphics/resource_09_contact.png) | [BIN](data/raw/resource_09.bin) |
| `$0A` | Fire overlay (33 frames) | [Contact sheet](data/graphics/resource_0A_contact.png) | [BIN](data/raw/resource_0A.bin) |
| `$0B` | Out-of-fuel overlay (26 frames) | [Contact sheet](data/graphics/resource_0B_contact.png) | [BIN](data/raw/resource_0B.bin) |
| `$0C` | Out-of-fuel smoke effect (25 frames) | [Contact sheet](data/graphics/resource_0C_contact.png) | [BIN](data/raw/resource_0C.bin) |
| `$0D` | Speedometer (17 frames) | [Contact sheet](data/graphics/resource_0D_contact.png) | [BIN](data/raw/resource_0D.bin) |
| `$0E` | PIT notices / HUD refresh (6 frames) | [Contact sheet](data/graphics/resource_0E_contact.png) | [BIN](data/raw/resource_0E.bin) |
| `$0F` | Flag man / starting gun (36 frames) | [Contact sheet](data/graphics/resource_0F_contact.png) | [BIN](data/raw/resource_0F.bin) |
| `$10` | Faces A (44 frames) | [Contact sheet](data/graphics/resource_10_contact.png) | [BIN](data/raw/resource_10.bin) |
| `$11` | Faces B (44 frames) | [Contact sheet](data/graphics/resource_11_contact.png) | [BIN](data/raw/resource_11.bin) |
| `$38` | Racing cars (336 frames) | [Contact sheet](data/graphics/resource_38_contact.png) | [BIN](data/raw/resource_38.bin) |

## Retail circuit MiniMap preview objects

The ten previews each contain one five-plane 78×51 BOB; they are separate from the 320×256 backdrop. Event 11 reuses Indianapolis. Detailed record pointers and runtime wrapper are on [[Race, Car and Pit Runtime Structures#Miniature circuit preview and regional-map marker]].

| Circuit | Resource | PNG | Original data |
|---|---|---|---|
| Illinois | `$1B` | [PNG](data/graphics/resource_1B.png) | [BIN](data/raw/resource_1B.bin) |
| Indianapolis | `$22` | [PNG](data/graphics/resource_22.png) | [BIN](data/raw/resource_22.bin) |
| New Jersey | `$1D` | [PNG](data/graphics/resource_1D.png) | [BIN](data/raw/resource_1D.bin) |
| West Canada | `$18` | [PNG](data/graphics/resource_18.png) | [BIN](data/raw/resource_18.bin) |
| South California | `$19` | [PNG](data/graphics/resource_19.png) | [BIN](data/raw/resource_19.bin) |
| East Canada | `$1E` | [PNG](data/graphics/resource_1E.png) | [BIN](data/raw/resource_1E.bin) |
| Michigan | `$1A` | [PNG](data/graphics/resource_1A.png) | [BIN](data/raw/resource_1A.bin) |
| Colorado | `$21` | [PNG](data/graphics/resource_21.png) | [BIN](data/raw/resource_21.bin) |
| North California | `$20` | [PNG](data/graphics/resource_20.png) | [BIN](data/raw/resource_20.bin) |
| Kentucky | `$1F` | [PNG](data/graphics/resource_1F.png) | [BIN](data/raw/resource_1F.bin) |

## Circuit Backdrop, Foreground, Surface and Recovery

The ten quadruplets ($39..$69 except the inserted music/other presentation resources) have direct dual PNG/BIN links on [[Track Data and Runtime Setup#Original circuit files direct views and source data]]. Do not duplicate that 40-entry schedule here.

## Colour and extraction accuracy

- Full-screen pictures are genuinely decoded five-plane pixels. The output PNGs use the **established presentation palette**; a second `_race_palette.png` variant is also generated for non-track full-screen artwork, as the exact active palette depends on the program mode. **The source indices and untouched original BIN, not one PNG's palette guess, are authoritative**.
- The `$12` bank is decoded with source-index transparency and the presentation palette; frame indices are zero-based and included on the contact sheet.
- `$38` is decoded through the project’s dedicated two-plane car-resource decoder, preserving shared black tyre/detail pixels.
- Track resource previews are diagnostic displays of real class/mask/direction data. PNGs do not supersede gameplay encoding.
- Unknown/non-graphics resources are intentionally absent from the PNG list but retain their raw/packed links on the master schedule.

No existing Wiki image or source file should be deleted when importing this catalogue. It is additive to the previous diagrams and user-validated images.
