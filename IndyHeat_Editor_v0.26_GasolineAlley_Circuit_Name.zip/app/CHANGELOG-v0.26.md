# Indy Heat Circuit Editor v0.26

## Gasoline Alley circuit name

- Added an editable **Circuit name** field to Race mode for the name shown on Gasoline Alley.
- `name.bin` represents the proven 18-byte race-record field at `race+$70..+$81`: 17 display bytes followed by a NUL terminator.
- Names are limited to 17 printable ASCII characters. `<` and `@` remain reserved for the game's alignment/fill convention; the editor generates balanced padding automatically.
- Circuit ZIP export now adds `name.bin`, an exact `$12`-byte copy of the authored name field.
- Circuit ZIP import consumes `name.bin` when present. Existing eight-file circuit ZIPs without it remain valid and use the template/retail name. Name authoring is kept as package metadata so imported circuits cannot contaminate their shared retail host template.

## Runtime compatibility

- The proven `$68` `race_setup.bin` format is unchanged.
- Matching WHDLoad development slave **1.3 test 23** adds optional `circuit_xx/name.bin` loading and copies it to `race+$70..+$81` after the normal circuit setup has been applied.
- No Gasoline Alley renderer patch is required: the game already reads the name from the race record.

All v0.25 functionality is retained.
