(function(root){
'use strict';

/*
 * Indy Heat Circuit Editor v0.26 — Gasoline Alley circuit-name authoring.
 *
 * Runtime fact inherited from the current source/wiki state:
 *   race+$70..+$81 is the 18-byte Gasoline Alley display-name field.
 *   Bytes 0..16 are display data and byte 17 is NUL. Retail data uses '<'
 *   and '@' as invisible alignment/fill glyphs around the readable name.
 *
 * Package compatibility:
 *   race_setup.bin deliberately remains the proven $68 format.
 *   v0.26 adds an optional ninth package sidecar, name.bin, containing the
 *   exact 18 raw bytes. Older editor builds ignore the extra ZIP member.
 *   Name authoring is kept as package metadata instead of mutating the shared
 *   retail template record, so switching imported packages cannot leak a name
 *   into the host circuit used by another package.
 */

const NAME_OFFSET=0x70;
const NAME_SIZE=0x12;
const NAME_DISPLAY_SIZE=0x11;
const NAME_LEFT_FILL=0x3c; // '<'
const NAME_RIGHT_FILL=0x40; // '@'

function decodeNameBytes(bytes){
  if(!(bytes instanceof Uint8Array))bytes=new Uint8Array(bytes||[]);
  let s='';
  for(let i=0;i<Math.min(NAME_DISPLAY_SIZE,bytes.length);i++){
    const c=bytes[i];
    if(c===0)break;
    if(c===NAME_LEFT_FILL||c===NAME_RIGHT_FILL)s+=' ';
    else if(c>=32&&c<=126)s+=String.fromCharCode(c);
  }
  return s.replace(/\s+/g,' ').trim();
}

function encodeNameBytes(value){
  const name=String(value??'').replace(/\s+/g,' ').trim();
  if(!name)throw new Error('Circuit name must not be blank');
  if(name.length>NAME_DISPLAY_SIZE)throw new Error(`Circuit name is limited to ${NAME_DISPLAY_SIZE} characters`);
  for(let i=0;i<name.length;i++){
    const c=name.charCodeAt(i);
    if(c<32||c>126||c===NAME_LEFT_FILL||c===NAME_RIGHT_FILL)
      throw new Error("Circuit name must use printable ASCII and cannot contain '<' or '@'");
  }
  const out=new Uint8Array(NAME_SIZE);
  const free=NAME_DISPLAY_SIZE-name.length;
  const left=Math.floor(free/2),right=free-left;
  let p=0;
  for(let i=0;i<left;i++)out[p++]=NAME_LEFT_FILL;
  for(let i=0;i<name.length;i++)out[p++]=name.charCodeAt(i);
  for(let i=0;i<right;i++)out[p++]=NAME_RIGHT_FILL;
  out[NAME_DISPLAY_SIZE]=0;
  return out;
}

function addNameFileToZipBytes(P,zipBytes,circuitIndex,nameBytes){
  if(!P||typeof P.readZipStore!=='function'||typeof P.zipStore!=='function'||typeof P.circuitFolder!=='function')
    throw new Error('Circuit package tools are unavailable');
  if(!(nameBytes instanceof Uint8Array))nameBytes=new Uint8Array(nameBytes||[]);
  if(nameBytes.length!==NAME_SIZE)throw new Error(`name.bin must be exactly $${NAME_SIZE.toString(16).toUpperCase()} bytes`);
  const entries=P.readZipStore(zipBytes);
  entries.set(`${P.circuitFolder(circuitIndex)}/name.bin`,nameBytes.slice());
  return P.zipStore([...entries.entries()].map(([name,data])=>({name,data})));
}

const api={NAME_OFFSET,NAME_SIZE,NAME_DISPLAY_SIZE,decodeNameBytes,encodeNameBytes,addNameFileToZipBytes};
root.IndyHeatCircuitNameTools=api;
if(typeof module!=='undefined'&&module.exports)module.exports=api;
if(typeof document==='undefined')return;

const $=id=>document.getElementById(id);
let bootTimer=null;
let zipHookBusy=false;
const authoredNames=new Map();

function tools(){return root.IndyHeatTools||null;}
function packageTools(){return root.IndyHeatCircuitPackage||null;}
function capture(){return root.IndyHeatRaceSetupCapture||null;}
function trackIndex(){return Number($('trackSelect')?.value||0);}
function primaryModel(){const C=capture();return C?.model||C?.layerModel||C?.coreModel||C?.models?.[0]||null;}
function recordsFor(model){
  const C=capture(),T=tools();if(!model||!T)return [];
  let records=C?.recordsByMain?.get(model.main)||null;
  if(!records){records=T.parseRaceRecords(model.main);C?.recordsByMain?.set(model.main,records);}
  for(const r of records){
    if(r.baseResourceId==null&&typeof T.raceBaseResourceId==='function')
      r.baseResourceId=T.raceBaseResourceId(r,model.resourceTableOffset+0x1000);
  }
  return records;
}
function recordFor(model,index=trackIndex()){
  const T=tools();if(!model||!T)return null;
  const base=T.TRACK_BASE_IDS?.[index];
  return recordsFor(model).find(r=>r.baseResourceId===base)||null;
}
function currentCircuitIndex(){
  const n=Number($('circuitNumber')?.value);
  return Number.isInteger(n)&&n>=0&&n<=99?n:trackIndex();
}
function nameBytesFor(model,record){
  if(!model||!record)return null;
  return model.main.slice(record.offset+NAME_OFFSET,record.offset+NAME_OFFSET+NAME_SIZE);
}
function currentNameBytes(){
  const key=currentCircuitIndex(),authored=authoredNames.get(key);
  if(authored)return authored.slice();
  const m=primaryModel(),r=recordFor(m),b=nameBytesFor(m,r);
  if(!b||b.length!==NAME_SIZE)throw new Error('Current circuit name field is unavailable');
  return b;
}
function currentName(){return decodeNameBytes(currentNameBytes());}
function setVersion(){
  const h=document.querySelector('header h1');
  if(h)h.textContent='Indy Heat Amiga — Circuit Editor v0.26';
  document.title='Indy Heat Amiga – Circuit Editor v0.26';
}
function setRaceStatus(text){const e=$('raceSetupStatus');if(e)e.textContent=text;}
function setTopStatus(text,bad=false){
  const e=$('circuitPackageTopStatus');if(!e)return;
  e.textContent=text;e.classList.toggle('bad',!!bad);
}
function updateCounter(){
  const input=$('raceCircuitName'),out=$('raceCircuitNameCount');if(!input||!out)return;
  out.textContent=`${input.value.length}/${NAME_DISPLAY_SIZE}`;
}
function syncNameUi(force=false){
  const input=$('raceCircuitName');if(!input)return false;
  if(!force&&document.activeElement===input&&input.dataset.editing==='1')return true;
  try{input.value=currentName();}catch(_e){return false;}
  input.dataset.editing='';updateCounter();
  return true;
}
function installNameUi(){
  const grid=$('raceLaps')?.closest('.raceSetupGrid');
  if(!grid)return false;
  if(!$('raceCircuitName')){
    const label=document.createElement('label');label.className='raceSetupWide';
    label.innerHTML=`Circuit name <span style="display:flex;gap:7px;align-items:center"><input id="raceCircuitName" type="text" maxlength="${NAME_DISPLAY_SIZE}" autocomplete="off" spellcheck="false" title="Gasoline Alley circuit name; 1–${NAME_DISPLAY_SIZE} printable ASCII characters"><output id="raceCircuitNameCount" style="min-width:4.5ch;text-align:right"></output></span><span class="muted" style="font-size:10px;line-height:1.25">Displayed on Gasoline Alley. Exported as the optional 18-byte name.bin package sidecar.</span>`;
    grid.insertBefore(label,grid.firstChild);
    const input=$('raceCircuitName');
    input.addEventListener('input',()=>{input.dataset.editing='1';updateCounter();});
  }
  const apply=$('raceApply');
  if(apply&&!apply.dataset.v026CircuitName){
    apply.dataset.v026CircuitName='1';
    apply.addEventListener('click',e=>{
      try{
        const bytes=encodeNameBytes($('raceCircuitName').value);
        authoredNames.set(currentCircuitIndex(),bytes);
        $('raceCircuitName').dataset.editing='';
      }catch(err){
        e.preventDefault();e.stopImmediatePropagation();setRaceStatus(`ERROR: ${err.message}`);
      }
    },true);
    apply.addEventListener('click',()=>setTimeout(()=>syncNameUi(true),0));
  }
  const revert=$('raceRevert');
  if(revert&&!revert.dataset.v026CircuitName){
    revert.dataset.v026CircuitName='1';
    revert.addEventListener('click',()=>{
      authoredNames.delete(currentCircuitIndex());
      setTimeout(()=>syncNameUi(true),0);
    },true);
  }
  if(!$('trackSelect')?.dataset.v026CircuitName){
    const sel=$('trackSelect');if(sel){sel.dataset.v026CircuitName='1';sel.addEventListener('change',()=>setTimeout(()=>syncNameUi(true),0));}
  }
  if(!$('circuitNumber')?.dataset.v026CircuitName){
    const n=$('circuitNumber');if(n){n.dataset.v026CircuitName='1';n.addEventListener('change',()=>setTimeout(()=>syncNameUi(true),0));}
  }
  syncNameUi();
  return true;
}

function installNameImport(){
  const input=$('circuitPackageInput'),P=packageTools();if(!input||!P)return false;
  if(input.dataset.v026CircuitName)return true;
  input.dataset.v026CircuitName='1';
  input.addEventListener('change',e=>{
    const file=e.target.files?.[0];if(!file)return;
    (async()=>{
      try{
        const entries=P.readZipStore(new Uint8Array(await file.arrayBuffer()));
        let circuitIndex=null,hit=null;
        for(const [name,data] of entries){
          const root=/^circuit_(\d{2})\//.exec(name);if(root&&circuitIndex==null)circuitIndex=Number(root[1]);
          const m=/^circuit_(\d{2})\/name\.bin$/.exec(name);
          if(m){hit={circuitIndex:Number(m[1]),bytes:data};break;}
        }
        if(!hit){if(circuitIndex!=null)authoredNames.delete(circuitIndex);setTimeout(()=>syncNameUi(true),50);return;}
        if(hit.bytes.length!==NAME_SIZE)throw new Error(`name.bin must be exactly $${NAME_SIZE.toString(16).toUpperCase()} bytes`);
        if(hit.bytes[NAME_DISPLAY_SIZE]!==0)throw new Error('name.bin byte 17 must be the terminating NUL');
        authoredNames.set(hit.circuitIndex,hit.bytes.slice());
        setTimeout(()=>syncNameUi(true),50);
      }catch(err){setTopStatus(`ERROR: ${err.message}`,true);}
    })();
  },true);
  return true;
}

function installNameExport(){
  const button=$('circuitPackageZip'),P=packageTools();if(!button||!P)return false;
  if(button.dataset.v026CircuitName)return true;
  button.dataset.v026CircuitName='1';
  button.addEventListener('click',()=>{
    if(zipHookBusy)return;
    zipHookBusy=true;
    const nativeCreate=URL.createObjectURL;
    const nativeClick=HTMLAnchorElement.prototype.click;
    let zipBlob=null,downloadName='';
    URL.createObjectURL=function(blob){
      if(!zipBlob&&blob instanceof Blob&&blob.type==='application/zip')zipBlob=blob;
      return nativeCreate.call(URL,blob);
    };
    HTMLAnchorElement.prototype.click=function(){
      if(zipBlob&&/\.zip$/i.test(this.download||'')){downloadName=this.download;return;}
      return nativeClick.call(this);
    };
    setTimeout(async()=>{
      URL.createObjectURL=nativeCreate;
      HTMLAnchorElement.prototype.click=nativeClick;
      zipHookBusy=false;
      if(!zipBlob)return;
      try{
        const original=new Uint8Array(await zipBlob.arrayBuffer());
        const nameBytes=currentNameBytes();
        const circuitIndex=currentCircuitIndex();
        const zip=addNameFileToZipBytes(P,original,circuitIndex,nameBytes);
        const blob=new Blob([zip],{type:'application/zip'});
        const a=document.createElement('a');
        a.href=nativeCreate.call(URL,blob);
        a.download=downloadName||`${P.circuitFolder(circuitIndex)}.zip`;
        nativeClick.call(a);
        setTimeout(()=>URL.revokeObjectURL(a.href),1000);
        setTopStatus(`${P.circuitFolder(circuitIndex)} exported with 9 runtime files including name.bin.`);
      }catch(err){setTopStatus(`ERROR: ${err.message}`,true);}
    },0);
  },true);
  return true;
}

function tick(){
  setVersion();
  return installNameUi()&&installNameImport()&&installNameExport();
}
function boot(){
  let tries=0;tick();
  bootTimer=setInterval(()=>{if(tick()||++tries>400){clearInterval(bootTimer);bootTimer=null;}},50);
  document.addEventListener('indyheat-race-setup-capture',()=>setTimeout(()=>syncNameUi(true),0));
  setTimeout(setVersion,1200);
  setTimeout(setVersion,3200);
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>setTimeout(boot,0),{once:true});
else setTimeout(boot,0);

})(typeof globalThis!=='undefined'?globalThis:this);
